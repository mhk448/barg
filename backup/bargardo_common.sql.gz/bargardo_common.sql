-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 29, 2015 at 12:13 AM
-- Server version: 5.5.42-cll
-- PHP Version: 5.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bargardo_common`
--

-- --------------------------------------------------------

--
-- Table structure for table `credits`
--

CREATE TABLE IF NOT EXISTS `credits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `subsite` varchar(10) NOT NULL,
  `ref_table` enum('projects','payments','payouts','sms','users','review_requests') NOT NULL,
  `ref_id` int(11) NOT NULL,
  `comment` tinytext NOT NULL,
  `dateline` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `credits`
--

INSERT INTO `credits` (`id`, `user_id`, `price`, `subsite`, `ref_table`, `ref_id`, `comment`, `dateline`) VALUES
(1, 8, 2000, 'translate', 'payments', 2, 'online auto accept', 1432566886),
(2, 9, 10000, 'translate', 'payments', 4, 'online auto accept', 1432567203);

-- --------------------------------------------------------

--
-- Table structure for table `discount`
--

CREATE TABLE IF NOT EXISTS `discount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `percent` int(3) NOT NULL,
  `price` int(11) NOT NULL,
  `used` tinyint(1) NOT NULL,
  `final_price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `kart_requests`
--

CREATE TABLE IF NOT EXISTS `kart_requests` (
  `user_id` int(11) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `shenasname` varchar(11) NOT NULL,
  `codemeli` varchar(11) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `city` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `zipcode` varchar(12) NOT NULL,
  `scan_shenasname` varchar(50) NOT NULL,
  `scan_kartmeli` varchar(50) NOT NULL,
  `verified` int(2) NOT NULL DEFAULT '0',
  `dateline` int(10) unsigned NOT NULL,
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `lock_credit`
--

CREATE TABLE IF NOT EXISTS `lock_credit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `subsite` varchar(20) NOT NULL,
  `prj_id` int(11) NOT NULL,
  `locked` int(3) NOT NULL DEFAULT '1',
  `price` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `lock_credit`
--

INSERT INTO `lock_credit` (`id`, `user_id`, `subsite`, `prj_id`, `locked`, `price`, `date`) VALUES
(1, 9, 'translate', 44, 1, 10000, 1432567203),
(2, 8, 'translate', 44, 1, 2000, 1432567203);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `from_id` int(11) NOT NULL,
  `to_id` int(11) NOT NULL,
  `reply_id` int(11) NOT NULL,
  `subsite` varchar(20) NOT NULL,
  `project_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `body` text,
  `dateline` int(10) unsigned NOT NULL,
  `attached_file` varchar(40) DEFAULT NULL,
  `readed` tinyint(4) NOT NULL DEFAULT '0',
  `is_support` tinyint(4) NOT NULL DEFAULT '0',
  `verified` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `payment_type` enum('Bank','Online') NOT NULL DEFAULT 'Bank',
  `bank_name` varchar(20) DEFAULT NULL,
  `bank_pay_type` enum('Card','Account') DEFAULT NULL,
  `transaction_id` varchar(40) DEFAULT NULL,
  `price` int(10) unsigned DEFAULT NULL,
  `resource_bank_code` varchar(20) DEFAULT NULL,
  `pay_date` varchar(50) DEFAULT NULL,
  `verified` tinyint(3) NOT NULL DEFAULT '0',
  `payment_for` enum('IrType','Project') NOT NULL DEFAULT 'IrType',
  `redirect_path` varchar(300) NOT NULL,
  `dateline` int(10) unsigned NOT NULL,
  `tref` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `user_id`, `payment_type`, `bank_name`, `bank_pay_type`, `transaction_id`, `price`, `resource_bank_code`, `pay_date`, `verified`, `payment_for`, `redirect_path`, `dateline`, `tref`) VALUES
(1, 9, 'Online', 'پارس پال', NULL, NULL, 1000, NULL, NULL, -1, 'IrType', '', 1432473779, ''),
(2, 8, 'Online', 'پارس پال', NULL, NULL, 2000, NULL, '1432566886', 1, 'IrType', '', 1432566784, '13010672987'),
(3, 9, 'Online', 'پارس پال', NULL, NULL, 10000, NULL, NULL, -1, 'IrType', 'accept-bid_1_AB1', 1432567067, ''),
(4, 9, 'Online', 'پارس پال', NULL, NULL, 10000, NULL, '1432567203', 1, 'IrType', 'accept-bid_1_AB1', 1432567151, '13010673008');

-- --------------------------------------------------------

--
-- Table structure for table `payouts`
--

CREATE TABLE IF NOT EXISTS `payouts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `bank_name` varchar(20) DEFAULT NULL,
  `bank_pay_type` enum('Card','Account') DEFAULT NULL,
  `transaction_id` varchar(40) DEFAULT NULL,
  `price` int(10) unsigned DEFAULT NULL,
  `resource_bank_code` varchar(20) DEFAULT NULL,
  `pay_date` varchar(12) DEFAULT NULL,
  `verified` tinyint(3) NOT NULL DEFAULT '0',
  `payment_for` enum('IrType','Project') NOT NULL DEFAULT 'IrType',
  `dateline` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `name` varchar(50) NOT NULL,
  `value` varchar(50) NOT NULL,
  `comment` varchar(50) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sms`
--

CREATE TABLE IF NOT EXISTS `sms` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sender` int(11) NOT NULL,
  `receiver` int(11) NOT NULL,
  `subsite` varchar(20) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `message` tinytext NOT NULL,
  `service_id` bigint(20) NOT NULL,
  `dateline` int(11) NOT NULL,
  `verified` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `sms`
--

INSERT INTO `sms` (`id`, `sender`, `receiver`, `subsite`, `phone`, `message`, `service_id`, `dateline`, `verified`) VALUES
(1, 4, 8, 'translate', '09369174883', 'پیشنهاد انجام پروژه با کد B44 تایید شد\\nبرگردون', 5025929687997893199, 1432567203, 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `userpass` char(32) NOT NULL,
  `email` varchar(60) NOT NULL,
  `state` enum('Active','Inactive','Banned','FirstDay') NOT NULL DEFAULT 'Inactive',
  `login_key` char(32) NOT NULL,
  `credits` int(15) NOT NULL DEFAULT '0',
  `locked_credits` int(11) NOT NULL DEFAULT '0',
  `referer_id` int(11) DEFAULT NULL,
  `reg_date_com` int(10) unsigned NOT NULL DEFAULT '0',
  `fullname` varchar(40) DEFAULT NULL,
  `nickname` varchar(30) NOT NULL,
  `ssn` char(14) DEFAULT NULL COMMENT 'kode meli',
  `gender` enum('Male','Female') DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `bank_name` varchar(20) DEFAULT NULL,
  `bank_account` varchar(40) DEFAULT NULL,
  `bank_card` varchar(20) DEFAULT NULL,
  `bank_shaba` varchar(60) DEFAULT NULL,
  `send_notify_email` tinyint(4) NOT NULL DEFAULT '0',
  `send_projects_list` tinyint(4) NOT NULL DEFAULT '1',
  `send_bid_email` tinyint(1) NOT NULL DEFAULT '1',
  `send_sms_system` tinyint(1) NOT NULL DEFAULT '1',
  `send_sms_user` tinyint(1) NOT NULL DEFAULT '1',
  `detail` varchar(500) NOT NULL,
  `signs` varchar(200) DEFAULT NULL,
  `specs` varchar(300) DEFAULT NULL COMMENT 'fa=> tavanaeeha',
  `prestige` int(4) NOT NULL DEFAULT '40',
  `admin_comment` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=101 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `userpass`, `email`, `state`, `login_key`, `credits`, `locked_credits`, `referer_id`, `reg_date_com`, `fullname`, `nickname`, `ssn`, `gender`, `phone`, `mobile`, `city`, `address`, `bank_name`, `bank_account`, `bank_card`, `bank_shaba`, `send_notify_email`, `send_projects_list`, `send_bid_email`, `send_sms_system`, `send_sms_user`, `detail`, `signs`, `specs`, `prestige`, `admin_comment`) VALUES
(1, 'Administrator', 'ed2b1f468c5f915f3f1cf75d7068baae', 'admin@e', 'Active', '', 0, 0, NULL, 1336358887, NULL, '', NULL, 'Male', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 0, 1, 1, '', NULL, NULL, 40, ''),
(2, 'Suport', 'ed2b1f468c5f915f3f1cf75d7068baae', 'Suport@.ir', 'Active', '', 0, 0, NULL, 1336358887, 'پشتیبان', 'پشتیبان', '', '', '', '09381499520', '', '', '', '', '', '', 0, 1, 0, 1, 1, '', '', NULL, 40, ''),
(3, 'elmend', 'ed2b1f468c5f915f3f1cf75d7068baae', 'elmend@.ir', 'Active', '', 0, 0, NULL, 1336358887, 'ddddddddfffff', '', '', '', '', '', '', '', '', '', '', '', 0, 1, 0, 1, 1, '', '', NULL, 40, '{"1399633227":{"u":"3","t":"fullname","m":"66"},"1399633503":{"u":"3","t":"fullname","m":"gg"},"1399637262":{"u":"3","t":"fullname","m":"rfff"},"1399637303":{"u":"3","t":"fullname","m":"dddddd"}}'),
(4, 'sms', 'ed2b1f468c5f915f3f1cf75d7068baae', 'sms@.i', 'Active', 'URHDHHQXKBSGJLVLXFAJFYRSPVSLUBOP', 0, 0, NULL, 1336358887, '', '', '', 'Male', '', '', '', '', '', '', '', '', 0, 1, 0, 1, 1, '', NULL, NULL, 40, ''),
(7, 'typeiran', 'ed2b1f468c5f915f3f1cf75d7068baae', 'typeiran@.ir', 'Active', '', -1474400, 0, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 1, 1, '', NULL, NULL, 40, ''),
(8, 'worker', 'ed2b1f468c5f915f3f1cf75d7068baae', 'worker@.ir', 'Active', 'SABCJDQCLZBVQRKJEVJGEJZBCIPEIXLB', 2000, 2000, NULL, 0, 'مترجم خوب', '', '', '', '', '09369174883', '', '', '', '', '', '', 0, 1, 0, 1, 1, '', '', NULL, 40, '{"158628":{"u":"uuuuu","t":"","m":"d0000f"},"1343":{"u":"aaaaaa","t":"","m":"d11111f"},"1398487322":{"u":"50","t":"","m":"gggggggg"}}'),
(9, 'user', 'ed2b1f468c5f915f3f1cf75d7068baae', 'user@.ir', 'Active', 'ABCHFXDGNLNDWDQQDMMWJABIORGOOLDO', 10000, 10000, NULL, 0, 'کار کارفرمایی', 'کارفرما نمونه', '', '', '', '09177249511', '', '', '', '', '', '', 1, 1, 1, 1, 1, '', '', NULL, 40, '{"1430594373":{"u":"9","t":"mobile","m":"09369174883"},"1431951256":{"u":"9","t":"mobile","m":"09381499520"},"1431951380":{"u":"9","t":"mobile","m":"09369174883"}}'),
(10, 'agency', 'ed2b1f468c5f915f3f1cf75d7068baae', 'agency@.ir', 'Active', 'EMDLMUJQDACDZZRGYWQSCJNBIDBYOBZT', 278500, 0, NULL, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 1, 1, '', NULL, NULL, 140, '11jjjjj1gggggg'),
(50, 'mhk448', 'ed2b1f468c5f915f3f1cf75d7068baae', 'info@mhk448.ir', 'Active', 'RZISEJFLRYBJCACGYJBIXMCQOFOYFZAW', 0, 0, NULL, 0, 'محمد هاشمی', 'مدیر فنی', '', '', '', '09381499520', '', '', 'پاسارگاد', '435', '4', '8999', 0, 1, 0, 1, 1, '', '', NULL, 40, '{"1430072033":{"u":"50","t":"fullname","m":"\\u0645"}}'),
(51, 'Bargardoon', 'ed2b1f468c5f915f3f1cf75d7068baae', 'javad123@gmail.com', 'FirstDay', '', 0, 0, 0, 0, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 1, 1, 'khu3Ifqav8HI3kVoOVnMKQInWWvLix87D7dkThk5nHBhbuJX5h0l5cetOp+TSooDKn5nO4Z+V66ubGcfttcW7g==', NULL, NULL, 40, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_comment`
--

CREATE TABLE IF NOT EXISTS `user_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `worker_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `subsite` varchar(20) NOT NULL,
  `comment` text NOT NULL,
  `verified` int(3) NOT NULL DEFAULT '0',
  `dateline` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_referer_site`
--

CREATE TABLE IF NOT EXISTS `user_referer_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `site` varchar(200) DEFAULT NULL,
  `dateline` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `user_referer_site`
--

INSERT INTO `user_referer_site` (`id`, `user_id`, `site`, `dateline`) VALUES
(1, 0, 'http://www.parspal.com/xGateway/Result.aspx?SID=f8adc37ebe824b479e91f6df1002c7ce', 1432566885),
(2, 0, 'http://www.parspal.com/xGateway/Result.aspx?SID=0ea4ae4a77384f4d8c53cd50a4ef14d6', 1432567202),
(3, 0, 'http://www.parspal.com/xGateway/Result.aspx?SID=0ea4ae4a77384f4d8c53cd50a4ef14d6', 1432567203),
(4, 0, 'http://www.parspal.com/xGateway/Result.aspx?SID=0ea4ae4a77384f4d8c53cd50a4ef14d6', 1432567204),
(5, 0, 'http://hs.kashanu.ac.ir/login', 1432568416),
(6, 0, 'http://saeidahmadi.mihanblog.com/post/36', 1432573812),
(7, 0, 'http://saeidahmadi.mihanblog.com/post/36', 1432574413),
(8, 0, 'http://saeidahmadi.mihanblog.com/post/36', 1432575058),
(9, 0, 'http://saeidahmadi.mihanblog.com/post/36', 1432575061),
(10, 0, 'http://samandehi.ir/webSites.html?conversationContext=5', 1432648964),
(11, 0, 'http://samandehi.ir/webSites.html?stype=1', 1432649485),
(12, 0, 'BARGARDOON.com/admin/fckeditor/editor/filemanager/upload/php/upload.php', 1432667364),
(13, 0, 'BARGARDOON.com/admin/fckeditor/editor/filemanager/upload/php/upload.phpindex.php', 1432667364),
(14, 0, 'http://whois.domaintools.com/bargardoon.net', 1432675757),
(15, 0, 'http://whois.domaintools.com/bargardon.ir', 1432676899),
(16, 0, 'http://saeidahmadi.mihanblog.com/', 1432719016),
(17, 0, 'http://yandex.ru/clck/jsredir?from=yandex.ru%3Bsearch%3Bweb%3B%3B&text=&etext=701.QAY26YvbJWhUjDl9VZGtO2n9oIw6ev7nwho0qFmf8Ce6DrV1vuHIOZu_r8417el0.7934e7cd46ed3edce1a99fceb82324ed05491985&uuid=&state=', 1432741127),
(18, 0, 'http://saeidahmadi.mihanblog.com/post/category/30', 1432759362),
(19, 0, 'http://saeidahmadi.mihanblog.com/post/category/30', 1432769234);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
