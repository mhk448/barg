-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 29, 2015 at 12:13 AM
-- Server version: 5.5.42-cll
-- PHP Version: 5.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bargardo_translate`
--

-- --------------------------------------------------------

--
-- Table structure for table `ability`
--

CREATE TABLE IF NOT EXISTS `ability` (
  `user_id` int(11) unsigned NOT NULL,
  `lang` varchar(10) NOT NULL,
  `can` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `bids`
--

CREATE TABLE IF NOT EXISTS `bids` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(11) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `dateline` int(10) unsigned NOT NULL,
  `earnest` int(11) NOT NULL,
  `price` int(10) unsigned DEFAULT NULL,
  `type` enum('Full','Perpage') NOT NULL DEFAULT 'Full',
  `message` text,
  `attached_file` varchar(40) DEFAULT NULL,
  `accepted` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `user_id` (`user_id`),
  KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `bids`
--

INSERT INTO `bids` (`id`, `project_id`, `user_id`, `dateline`, `earnest`, `price`, `type`, `message`, `attached_file`, `accepted`) VALUES
(1, 44, 8, 1432567007, 10000, 10000, 'Full', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contents`
--

CREATE TABLE IF NOT EXISTS `contents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_type` enum('Worker','User','Agency','Admin','All') NOT NULL,
  `title` varchar(300) NOT NULL,
  `body` text NOT NULL,
  `verified` int(2) NOT NULL,
  `dateline` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `dateline` int(10) unsigned NOT NULL,
  `title` varchar(250) DEFAULT NULL,
  `body` text,
  `type` enum('bid','group','message','payment','payout','project','user') DEFAULT NULL,
  `action` enum('-1','-2','1','acc','cancel','changecredit','close','edit','finalfilereceive','finalfilesubmit','invite','needstakeholder','payfee','private','receive','referer','request','review','run','send','signup','submit') DEFAULT NULL,
  `ref_id` int(11) DEFAULT NULL,
  `readed` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `user_id`, `dateline`, `title`, `body`, `type`, `action`, `ref_id`, `readed`) VALUES
(1, 9, 1432566539, ' ارسال پروژه', 'کاربر گرامی پروژه ی شما با عنوان  [  پروژه ی  کارفرما نمونه  ] با موفقیت ثبت شد<br/><a class="ajax" href="http://bargardoon.com/project_44">نمایش جزئیات پروژه</a>', 'project', 'submit', 44, 1),
(2, 8, 1432566886, ' تایید پرداخت', 'کاربر محترم، پرداخت شما در  برگردون  تایید شد و اعتبار آن به حساب کاربریتان افزوده گردید<br/><br/>مبلغ تایید شده:2000  ریال <br/> <p style="display:none">online auto accept</p>', 'payment', '-1', 0, 1),
(3, 8, 1432567007, ' ارسال پیشنهاد', 'کاربر گرامی پیشنهاد شما برای پروژه ی  پروژه ی  کارفرما نمونه  با موفقیت ارسال شد<br/><a class="ajax" href="http://bargardoon.com/project_44">نمایش جزئیات پروژه</a>', 'bid', 'submit', 44, 1),
(4, 9, 1432567007, ' ارسال پیشنهاد', 'کاربر گرامی برای پروژه ی  پروژه ی  کارفرما نمونه  پیشنهاد جدیدی ارسال شده است<br/><a class="ajax" href="http://bargardoon.com/project_44">نمایش جزئیات پروژه</a>', 'bid', 'receive', 44, 1),
(5, 9, 1432567203, ' تایید پرداخت', 'کاربر محترم، پرداخت شما در  برگردون  تایید شد و اعتبار آن به حساب کاربریتان افزوده گردید<br/><br/>مبلغ تایید شده:10000  ریال <br/> <p style="display:none">online auto accept</p>', 'payment', '-1', 0, 1),
(6, 8, 1432567203, ' قبول پیشنهاد', 'کاربر گرامی پیشنهاد شما برای پروژه ی  پروژه ی  کارفرما نمونه  مورد تایید قرار گرفته و برنده ی مناقصه شده است<br/>شما می توانید پروژه را شروع نمایید<br/><a class="ajax" href="http://bargardoon.com/project_44">نمایش جزئیات پروژه</a>', 'bid', 'acc', 44, 1),
(7, 8, 1432567203, ' شروع پروژه', 'کاربر گرامی اجرای پروژه ی شما با عنوان  [  پروژه ی  کارفرما نمونه  ]  شروع شد<br/><a class="ajax" href="http://bargardoon.com/project_44?start=1" target="_blank">نمایش جزئیات پروژه</a>', 'project', 'run', 44, 1),
(8, 9, 1432567203, ' شروع پروژه', 'کاربر گرامی اجرای پروژه ی شما با عنوان  [  پروژه ی  کارفرما نمونه  ]  شروع شد<br/><a class="ajax" href="http://bargardoon.com/project_44?start=1" target="_blank">نمایش جزئیات پروژه</a>', 'project', 'run', 44, 1),
(9, 8, 1432570514, ' ارسال فایل نهایی', 'کاربر گرامی فایل نهایی مربوط به پروژه ی  پروژه ی  کارفرما نمونه  با موفقیت ارسال شد<br/><a class="ajax" href="http://bargardoon.com/project_44">نمایش جزئیات پروژه</a>', 'project', 'finalfilesubmit', 44, 1),
(10, 9, 1432570514, ' دریافت فایل نهایی', 'کاربر گرامی فایل نهایی مربوط به پروژه ی  پروژه ی  کارفرما نمونه  آماده تحویل است <br/><a class="ajax" href="http://bargardoon.com/project_44">نمایش جزئیات پروژه</a>', 'project', 'finalfilereceive', 44, 0);

-- --------------------------------------------------------

--
-- Table structure for table `final_files`
--

CREATE TABLE IF NOT EXISTS `final_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `final_file` varchar(50) NOT NULL,
  `pages` int(10) unsigned DEFAULT '0',
  `message` text,
  `can_download` tinyint(4) NOT NULL DEFAULT '0',
  `project_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `dateline` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `final_files`
--

INSERT INTO `final_files` (`id`, `final_file`, `pages`, `message`, `can_download`, `project_id`, `user_id`, `dateline`) VALUES
(1, 'F143257051455634A92CC8A1.pdf', 0, '', 0, 44, 8, 1432570514);

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `creator` int(11) unsigned NOT NULL,
  `rank` int(11) NOT NULL,
  `rankers` int(11) NOT NULL,
  `verified` int(2) NOT NULL DEFAULT '2',
  `admin_comment` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`),
  KEY `creator` (`creator`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `group_files`
--

CREATE TABLE IF NOT EXISTS `group_files` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `project_id` int(11) unsigned NOT NULL,
  `file` varchar(50) NOT NULL,
  `message` varchar(300) DEFAULT NULL,
  `dateline` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `group_members`
--

CREATE TABLE IF NOT EXISTS `group_members` (
  `group_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `verified` int(2) NOT NULL,
  PRIMARY KEY (`group_id`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `level_a`
--

CREATE TABLE IF NOT EXISTS `level_a` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `q_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `answer_0` int(11) DEFAULT NULL,
  `answer_1` text,
  `answer_2` text,
  `answer_3` text,
  `answer_4` text,
  `answer_5` text,
  `dateline` int(11) NOT NULL,
  `readed` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `level_a`
--

INSERT INTO `level_a` (`id`, `q_id`, `user_id`, `answer_0`, `answer_1`, `answer_2`, `answer_3`, `answer_4`, `answer_5`, `dateline`, `readed`) VALUES
(1, 6, 50, 1, '', '', '', '', '', 1432433619, 0);

-- --------------------------------------------------------

--
-- Table structure for table `level_q`
--

CREATE TABLE IF NOT EXISTS `level_q` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `redirect_path` varchar(100) DEFAULT NULL,
  `interval` int(11) NOT NULL COMMENT 'after prvious anser (timestamp)',
  `user_type` varchar(20) NOT NULL,
  `next_level` int(11) NOT NULL COMMENT 'next level id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `level_q`
--

INSERT INTO `level_q` (`id`, `question`, `redirect_path`, `interval`, `user_type`, `next_level`) VALUES
(1, ' <div style="font-size: 16px ;text-align: center;padding: 10px;" id="i6">\n        <form action="panel" method="POST">\n            <input type="hidden" name="qid" value="5">\n            <input type="hidden" name="formName" value="userlevel">\n            <h1>\n                <img src="medias/images/icons/poll.png" alt="" height="32" width="32" align="absmiddle"  />\nافتتاح شد\n            </h1>\n            <hr style="width: 100%"/>\nسامانه ی «تایپ توئیت» افتتاح شد\n            <hr style="width: 100%"/>\n            <div id="f1">\n               از امروز می توانید اطلاعات و نظرات خود را در مورد امور تایپ، سایت تایپایران و... با دیگران به اشتراک بگذارید.\n                <br/><br/><hr style="width: 100%"/>\n                <a class="active_btn" href="/twitt">\n                    ورود به «تایپ توئیت»\n                </a>\n            </div>\n        </form>\n    </div>', NULL, 518400, 'Admin', 0),
(2, ' <div style="font-size: 16px ;text-align: center;padding: 10px;" id="i6">\n        <form action="panel" method="POST">\n            <input type="hidden" name="qid" value="5">\n            <input type="hidden" name="formName" value="userlevel">\n            <h1>\n                <img src="medias/images/icons/poll.png" alt="" height="32" width="32" align="absmiddle"  />\nافتتاح شد\n            </h1>\n            <hr style="width: 100%"/>\nسامانه ی «تایپ توئیت» افتتاح شد\n            <hr style="width: 100%"/>\n            <div id="f1">\n               از امروز می توانید اطلاعات و نظرات خود را در مورد امور تایپ، سایت تایپایران و... با دیگران به اشتراک بگذارید.\n                <br/><br/><hr style="width: 100%"/>\n                <a class="active_btn" href="/twitt">\n                    ورود به «تایپ توئیت»\n                </a>\n            </div>\n        </form>\n    </div>', NULL, 518400, 'Agency', 0),
(3, '<div style="font-size: 16px ;text-align: center;padding: 10px;">\r\n    <form action="panel" method="POST">\r\n        <input type="hidden" name="qid" value="3">\r\n        <input type="hidden" name="formName" value="userlevel">\r\n        <h1>\r\n            <img src="medias/images/icons/poll.png" alt="" height="32" width="32" align="absmiddle"  />\r\n            نظر سنجی!\r\n        </h1>\r\n        <hr style="width: 100%"/>\r\n        <div id="f1">\r\n            ..:: 5 سوال ::..\r\n            <br/>\r\n            تایپیست گرامی جهت ارتقای خدمات این سایت در نظرسنجی شرکت کنید        \r\n            <br/><br/><hr style="width: 100%"/>\r\n            <a class="active_btn" onclick="$(''#f1'').slideUp();$(''#f2'').slideDown();">\r\n                باشه\r\n            </a>\r\n        </div>\r\n        <div id="f2" style="display: none;">\r\n            1 . سایت تایپایران را چگونه ارزیابی می کنید؟\r\n            <br/>\r\n            <input type="radio" name="a0" value="1"/>\r\n            ضعیف\r\n            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n            <input type="radio" name="a0" value="2"/>\r\n            متوسط\r\n            <br/>\r\n            <input type="radio" name="a0" value="3"/>\r\n            خوب\r\n            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n            <input type="radio" name="a0" value="4"/>\r\n            عالی\r\n            &nbsp;\r\n            <br/>\r\n            <br/><hr style="width: 100%"/>\r\n            <a class="active_btn" onclick="$(''#f2'').slideUp();$(''#f1'').slideDown();">\r\n                قبلی \r\n            </a> \r\n\r\n            <a class="active_btn" onclick="$(''#f2'').slideUp();$(''#f3'').slideDown();">\r\n                بعدی\r\n            </a>\r\n        </div>\r\n        <div id="f3" style="display: none;">\r\n            2 . عملکرد نقش پشتیبانی و راهنمایی سایت چطور است؟\r\n\r\n            <br/>\r\n            <textarea name="a1" style="width: 90%;height: 70px" ></textarea>\r\n            <br/><hr style="width: 100%"/>\r\n            <a class="active_btn" onclick="$(''#f3'').slideUp();$(''#f2'').slideDown();">\r\n                قبلی \r\n            </a> \r\n\r\n            <a class="active_btn" onclick="$(''#f3'').slideUp();$(''#f4'').slideDown();">\r\n                بعدی\r\n            </a>\r\n        </div>\r\n        <div id="f4" style="display: none;">\r\n            3 .\r\n            به نظر شما کدام یک از امکانات سایت جالب توجه و کدام یک بی فایده است؟\r\n            <br/>\r\n            <textarea name="a2" style="width: 90%;height: 70px"></textarea>\r\n            <br/><hr style="width: 100%"/>\r\n            <a class="active_btn" onclick="$(''#f4'').slideUp();$(''#f3'').slideDown();">\r\n                قبلی \r\n            </a> \r\n\r\n            <a class="active_btn" onclick="$(''#f4'').slideUp();$(''#f5'').slideDown();">\r\n                بعدی\r\n            </a>\r\n        </div>\r\n        <div id="f5" style="display: none;">\r\n            4 .\r\n            به نظر شما کدام یک از بخش های سایت مبهم است و نیاز به راهنمایی دارد؟\r\n            <br/>\r\n            <textarea name="a3" style="width: 90%;height: 70px"></textarea>\r\n            <br/><hr style="width: 100%"/>\r\n            <a class="active_btn" onclick="$(''#f5'').slideUp();$(''#f4'').slideDown();">\r\n                قبلی \r\n            </a> \r\n\r\n            <a class="active_btn" onclick="$(''#f5'').slideUp();$(''#f6'').slideDown();">\r\n                بعدی\r\n            </a>\r\n        </div>\r\n        <div id="f6" style="display: none;">\r\n            5 .\r\n            به نظر شما جهت ارتقای سایت چه امکانات دیگری نیاز است؟\r\n            <br/>\r\n            <textarea name="a4" style="width: 90%;height: 70px"></textarea>\r\n            <br/><hr style="width: 100%"/>\r\n            <a class="active_btn" onclick="$(''#f6'').slideUp();$(''#f5'').slideDown();">\r\n                قبلی \r\n            </a> \r\n            <input type="submit" class="active_btn" value="ثبت"/>\r\n        </div>\r\n    </form>\r\n</div>\r\n<br/>\r\n<br/>', NULL, 518400, 'Worker', 0),
(4, ' <p style="font-size:14pt">به تایپایران خوش آمدید!</p>\r\n                <p style="font-size:12pt;line-height: 2;">نسخه جدید تایپایران با امکانات فراوان راه اندازی شد. برای دیدن لیست امکانات جدید \r\n                    <a href="http://blog.typeiran.com" target="_blank">\r\n                        اینجا</a>\r\n\r\n                    کلیک نمایید.در حال حاضر امکانات سایت رایگان میباشد</p><br/>\r\n               ', NULL, 518400, 'User', 0),
(5, '<div style="font-size: 16px ;text-align: center;padding: 10px;" id="i5">\r\n    <form action="panel" method="POST">\r\n        <input type="hidden" name="qid" value="5">\r\n        <input type="hidden" name="formName" value="userlevel">\r\n        <h1>\r\n            <img src="medias/images/icons/poll.png" alt="" height="32" width="32" align="absmiddle"  />\r\n            آگهی جذب مدیر\r\n        </h1>\r\n        <hr style="width: 100%"/>\r\n        <div id="f1">\r\n            ..:: جذب مدیر انجمن و وبلاگ ::..\r\n            <br/>\r\n            تایپایران در نظر دارد جهت تکمیل بخش مدیریت انجمن گفتگو، وبلاگ و ...\r\n            از تایپیست های فعال که حداقل 10 پروژه را با موفقیت انجام داده اند،\r\n ثبت نام نماید\r\n\r\n            <br/><br/><hr style="width: 100%"/>\r\n            <a class="active_btn" onclick="$(''#i5 #f1'').slideUp();$(''#i5 #f2'').slideDown();">\r\n                شرایط و امتیازات\r\n            </a>\r\n        </div>\r\n        <div id="f2" style="display: none;">\r\n\r\n            کاربرانی که علاقه مند به همکاری در بخش های انجمن گفتگو و وبلاگ هستند\r\n            می توانند درخواست خود را از همین طریق ارسال نمایند\r\n            <br/>\r\n            به تمامی افراد پذیرفته شده نشان تایپیست ویژه تعلق می گیرد\r\n\r\n            <br/>\r\n            <br/><hr style="width: 100%"/>\r\n            <a class="active_btn" onclick="$(''#i5 #f2'').slideUp();$(''#i5 #f1'').slideDown();">\r\n                قبلی \r\n            </a> \r\n\r\n            <a class="active_btn" onclick="$(''#i5 #f2'').slideUp();$(''#i5 #f3'').slideDown();">\r\n                بعدی\r\n            </a>\r\n        </div>\r\n        <div id="f3" style="display: none;">\r\n\r\n\r\n            نشان تایپیست ویژه دارای امکانات زیر است:\r\n            <ul>\r\n                <li>\r\n                    حذف میزان سود تایپیران از تمام پروژه ها\r\n                </li>\r\n                <small>(\r\n                تمام مبلغی که کارفرما پرداخت می کند به حساب تایپیست واریز می شود\r\n                )\r\n                </small>\r\n                <li>\r\n                ستاره دار شدن تمام پیشنهادهای ارسال شده توسط کاربر\r\n                </li>\r\n            </ul>\r\n\r\n            <br/>\r\n            <br/><hr style="width: 100%"/>\r\n            <a class="active_btn" onclick="$(''#i5 #f3'').slideUp();$(''#i5 #f2'').slideDown();">\r\n                قبلی \r\n            </a> \r\n\r\n            <a class="active_btn" onclick="$(''#i5 #f3'').slideUp();$(''#i5 #f4'').slideDown();">\r\n                فرم ثبت نام\r\n            </a>\r\n        </div>\r\n        <div id="f4" style="display: none;">\r\n\r\n            مهارت ها و تجربه های خودتان را وارد نمایید.\r\n            <br/>\r\n            <textarea name="a1" style="width: 90%;height: 70px"></textarea>\r\n            <br/>\r\n            بیشتر تمایل دارید در چه بخشی فعالیت نمایید؟\r\n            <br/>\r\n            <textarea name="a2" style="width: 90%;height: 70px"></textarea>\r\n            <br/><hr style="width: 100%"/>\r\n            <a class="active_btn" onclick="$(''#i5 #f4'').slideUp();$(''#i5 #f3'').slideDown();">\r\n                قبلی \r\n            </a> \r\n            <input type="submit" class="active_btn" value="ثبت"/>\r\n        </div>\r\n    </form>\r\n</div>\r\n<br/>\r\n<br/>', NULL, 518400, 'Worker', 0),
(6, '   <div style="font-size: 16px ;text-align: center;padding: 10px;" id="i6">\r\n        <form action="panel" method="POST">\r\n            <input type="hidden" name="qid" value="5">\r\n            <input type="hidden" name="formName" value="userlevel">\r\n            <h1>\r\n                <img src="medias/images/icons/poll.png" alt="" height="32" width="32" align="absmiddle"  />\r\n                آیا میدانید؟\r\n            </h1>\r\n            <hr style="width: 100%"/>\r\n            چگونه می توانید پروژه های بیشتری جذب کنید؟ \r\n            <hr style="width: 100%"/>\r\n            <div id="f1">\r\n                1.\r\n                نام مستعار مناسبی برای خود انتخاب کنید\r\n                <br/>\r\n                <small>\r\n                    از قسمت "تنظیمات" به بخش ویرایش اطلاعات مراجعه کنید و یک نام مستعار مناسب انتخاب کنید\r\n                </small>\r\n                <br/><br/><hr style="width: 100%"/>\r\n                <a class="active_btn" onclick="$(''#i6 #f1'').slideUp();$(''#i6 #f2'').slideDown();">\r\n                    بعدی\r\n                </a>\r\n            </div>\r\n            <div id="f2" style="display: none;">\r\n                2.\r\n                تصویر مناسبی برای حساب کاربری خود انتخاب کنید\r\n                <br/>\r\n                <small>\r\n                    کارفرمایان به تابپیستهایی که دارای مشخصات کامل تری هستند اعتماد بیشتری می کنند\r\n                </small>\r\n                <br/>\r\n                <br/><hr style="width: 100%"/>\r\n                <a class="active_btn" onclick="$(''#i6 #f2'').slideUp();$(''#i6 #f1'').slideDown();">\r\n                    قبلی \r\n                </a> \r\n\r\n                <a class="active_btn" onclick="$(''#i6 #f2'').slideUp();$(''#i6 #f3'').slideDown();">\r\n                    بعدی\r\n                </a>\r\n            </div>\r\n            <div id="f3" style="display: none;">\r\n                3.\r\n                در هنگام ارسال پیشنهاد به مبلغ تخمینی پروژه دقت کنید\r\n                <br/>\r\n                <small>\r\n                    فایل پروژه را حتما بررسی نمایید و قیمتی منصفانه پیشنهاد دهید \r\n                    شما می توانید قیمتی بالاتر و یا پایین تر از هزینه ی تخمینی کارفرما\r\n                    پیشنهاد دهید\r\n                </small>\r\n\r\n                <br/>\r\n                <br/><hr style="width: 100%"/>\r\n                <a class="active_btn" onclick="$(''#i6 #f3'').slideUp();$(''#i6 #f2'').slideDown();">\r\n                    قبلی \r\n                </a> \r\n\r\n                <a class="active_btn" onclick="$(''#i6 #f3'').slideUp();$(''#i6 #f4'').slideDown();">\r\n                    بعدی\r\n                </a>\r\n            </div>\r\n            <div id="f4" style="display: none;">\r\n                4.\r\n                پیشنهاد خود را با دقت وارد نمایید\r\n                <br/>\r\n                <small>\r\n                    در کادر مخصوص پیشنهاد قیمت پروژه، مبلغ مورد نظر را وارد نمایید\r\n                 دقت نمایید مبلغ وارد شده به ازای کل پروژه در نظر گرفته   \r\n                 خواهد شد.\r\n                از وارد کردن قیمت در قسمت توضیحات بپرهیزید\r\n                    در صورت وارد کردن قیمت در قسمت توضیحات از امتیاز شما کسر\r\n                    خواهد شد و مبلغ پروژه به حساب شما واریز نمی شود\r\n                </small>\r\n                <br/>\r\n                <br/><hr style="width: 100%"/>\r\n                <a class="active_btn" onclick="$(''#i6 #f4'').slideUp();$(''#i6 #f3'').slideDown();">\r\n                    قبلی \r\n                </a> \r\n\r\n                <a class="active_btn" onclick="$.ajax({url:''panel?qid=6&formName=userlevel&a0=1''});$(''#i6 #f4'').slideUp();$(''#i6 #f5'').slideDown();">\r\n                    بعدی\r\n                </a>\r\n            </div>\r\n            <div id="f5" style="display: none;">\r\n                این راهنمایی چطور بود؟\r\n                <br/>\r\n                <br/>\r\n                <br/><hr style="width: 100%"/>\r\n                <a class="active_btn" onclick="$.ajax({url:''panel?qid=6&formName=userlevel&a1=dontUsed''});$(''#i6'').slideUp();">\r\n                    مفید نبود \r\n                </a> \r\n                <a class="active_btn" onclick="$.ajax({url:''panel?qid=6&formName=userlevel&a1=useful''});$(''#i6'').slideUp();">\r\n                    مفید بود\r\n                </a>\r\n            </div>\r\n        </form>\r\n    </div>\r\n    <br/>\r\n    <br/>', NULL, 218400, 'Worker', 0),
(7, ' <div style="font-size: 16px ;text-align: center;padding: 10px;" id="i6">\n        <form action="panel" method="POST">\n            <input type="hidden" name="qid" value="5">\n            <input type="hidden" name="formName" value="userlevel">\n            <h1>\n                <img src="medias/images/icons/poll.png" alt="" height="32" width="32" align="absmiddle"  />\nافتتاح شد\n            </h1>\n            <hr style="width: 100%"/>\nسامانه ی «تایپ توئیت» افتتاح شد\n            <hr style="width: 100%"/>\n            <div id="f1">\n               از امروز می توانید اطلاعات و نظرات خود را در مورد امور تایپ، سایت تایپایران و... با دیگران به اشتراک بگذارید.\n                <br/><br/><hr style="width: 100%"/>\n                <a class="active_btn" href="/twitt">\n                    ورود به «تایپ توئیت»\n                </a>\n            </div>\n        </form>\n    </div>', NULL, 10000, 'Worker', 0),
(8, '<div style="font-size: 16px ;text-align: center;padding: 10px;" id="i6">\n        <form action="panel" method="POST">\n            <input type="hidden" name="qid" value="5">\n            <input type="hidden" name="formName" value="userlevel">\n            <h1 style="color: red">\n                <img src="medias/images/icons/poll.png" alt="" height="32" width="32" align="absmiddle"  />\nتغییرات سیستم\n            </h1>\n            <hr style="width: 100%"/>\nتایپیست های عزیز\n            <hr style="width: 100%"/>\n            <div id="f1">\nاز این پس در قسمت ارسال پیشنهاد برای انجام پروژه، مبلغ مورد نظر خود را به ازای\n<span style="color: red">\nهر صفحه\n</span>\nوارد نمایید\n\n<br/>\n\n            </div>\n        </form>\n    </div>', NULL, 518400, 'Worker', 0),
(9, '<div style="font-size: 16px ;text-align: center;padding: 10px;" id="i6">\r\n        <form action="panel" method="POST">\r\n            <input type="hidden" name="qid" value="9">\r\n            <input type="hidden" name="formName" value="userlevel">\r\n            <h1 style="color: red">\r\n                <img src="medias/images/icons/poll.png" alt="" height="32" width="32" align="absmiddle"  />\r\nکاندیدای برترین وب‌سایت\r\n            </h1>\r\n            \r\n            <hr style="width: 100%"/>\r\n            <div id="f1">\r\nتایپایران، به عنوان\r\n<span style="color: red">\r\n کاندیدای برترین وب سایت، ششمین جشنواره وب ایران از نگاه داوران \r\n</span>\r\nانتخاب گردید. این موفقیت را به همه کاربران عزیز که همیشه همراه و پشیتبان ما بوده اند تبریک می گوییم.\r\n<br/>\r\n<a target="_blank" style="color:blue" href="http://directory.iranwebfestival.com/websites/list/186">مشاهده نتایج داوری جشنواره</a>\r\n<br/><br/>\r\n<a href="http://directory.iranwebfestival.com/website/typeiran.com"><img width="250" src="http://blog.typeiran.com/wp-content/uploads/2014/02/Typeiran.jpg"></a>\r\n            </div>\r\n        </form>\r\n    </div>', NULL, 10, 'Worker', 0);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `body` text,
  `dateline` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(250) DEFAULT NULL,
  `subject` varchar(50) NOT NULL,
  `level` enum('student','normal','advance','') NOT NULL DEFAULT 'normal',
  `state` enum('Run','Finish','Open','Close') DEFAULT NULL,
  `submit_date` int(11) DEFAULT NULL,
  `type` enum('Public','Private','Protected','Agency','Referer') DEFAULT NULL,
  `bid_type` varchar(10) NOT NULL DEFAULT 'Full',
  `description` text,
  `demo` varchar(300) DEFAULT NULL,
  `file_name` varchar(200) DEFAULT NULL,
  `max_price` int(11) DEFAULT NULL,
  `lock_price` int(11) NOT NULL COMMENT 'price that must lock ,when loced add to earnest colomn',
  `earnest` int(11) NOT NULL COMMENT 'stackholder or price that payed',
  `min_rate` int(3) NOT NULL,
  `expire_interval` int(11) NOT NULL COMMENT 'fa=> bazeye tahvik',
  `expire_time` int(11) NOT NULL COMMENT 'fa=> tarkh tahvik',
  `verified` tinyint(4) NOT NULL DEFAULT '2' COMMENT '0=notActive,1=Active,2=AutoActive',
  `selection_method` enum('li','fm','fim','mr','emp') NOT NULL DEFAULT 'emp' COMMENT 'emp=empty',
  `typist_id` int(10) unsigned NOT NULL,
  `group_id` int(11) unsigned DEFAULT NULL,
  `group_split_info` varchar(200) DEFAULT NULL,
  `private_typist_id` int(10) unsigned DEFAULT NULL,
  `lang` varchar(8) NOT NULL,
  `stakeholdered` tinyint(4) NOT NULL DEFAULT '0',
  `accepted_price` int(11) NOT NULL DEFAULT '0',
  `elmend_price` int(11) NOT NULL,
  `stakeholder_date` int(10) unsigned NOT NULL DEFAULT '0',
  `ranked_typist` tinyint(4) NOT NULL DEFAULT '-1',
  `guess_page_num` int(11) NOT NULL,
  `output` enum('DOC','ONLINE','DOCX','PPTX','XLSX') NOT NULL DEFAULT 'DOCX',
  `discount_code` varchar(20) NOT NULL,
  `can_cancel` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=45 ;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `user_id`, `title`, `subject`, `level`, `state`, `submit_date`, `type`, `bid_type`, `description`, `demo`, `file_name`, `max_price`, `lock_price`, `earnest`, `min_rate`, `expire_interval`, `expire_time`, `verified`, `selection_method`, `typist_id`, `group_id`, `group_split_info`, `private_typist_id`, `lang`, `stakeholdered`, `accepted_price`, `elmend_price`, `stakeholder_date`, `ranked_typist`, `guess_page_num`, `output`, `discount_code`, `can_cancel`) VALUES
(44, 9, 'پروژه ی  کارفرما نمونه', '', '', 'Run', 1432566539, 'Public', 'Full', 'جواد', '', '["F1432525022308U9I0.png"]', 0, 2000, 10000, 0, 345600, 1432912803, 2, 'li', 8, NULL, NULL, 0, 'EN2FA', 1, 10000, 0, 1432567203, -1, 1, '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `representative_requests`
--

CREATE TABLE IF NOT EXISTS `representative_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fullname` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `scope` varchar(50) DEFAULT NULL,
  `project_scale` varchar(10) DEFAULT NULL,
  `address` text,
  `files` varchar(200) DEFAULT NULL,
  `description` text,
  `dateline` int(10) unsigned DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `readed` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `review_requests`
--

CREATE TABLE IF NOT EXISTS `review_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `project_id` int(10) unsigned DEFAULT NULL,
  `body` text,
  `dateline` int(10) unsigned DEFAULT NULL,
  `readed` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `name` varchar(50) NOT NULL,
  `value` varchar(50) NOT NULL,
  `comment` varchar(50) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`name`, `value`, `comment`) VALUES
('closeProject_age', '4', 'بستن پروژه های باز بعد از(روز)'),
('closeProject_delay', '86400', 'بررسی و بستن پروژه های باز هر'),
('closeProject_last', '1432844028', 'آخرین بررسی پروژه های باز'),
('dailyBackupSub_delay', '86400', 'پشتیبان گیری روزانه تایپ'),
('dailyBackupSub_last', '1400865071', 'آخرین پشتیبان گیری روزانه تایپ'),
('delOldFile_age', '۱۵', 'حذف فایل پروژه هاها بعد از (روز)'),
('delOldFile_delay', '86400', 'بررسی فایل ها هر'),
('delOldFile_last', '1432871560', 'آخرین بررسی فایل ها'),
('finishProject_delay', '86400', 'بررسی پروژه های تمام نشده'),
('finishProject_last', '1432747055', 'آخرین بررسی پروژه های تمام نشده'),
('fullBackupSub_delay', '2592000', 'پشتیبان گیری ماهانه تایپ'),
('fullBackupSub_last', '1402855538', 'آخرین پشتیبان گیری ماهانه تایپ'),
('homeRate_delay', '86400', 'بررسی رتبه ها هر'),
('homeRate_last', '1405196651', 'آخرین بروز رسانی تایپیست برتر'),
('homeRate_userActive', '[8]', 'مجری فعال ۷ روز'),
('homeRate_userTop', 'null', 'مجری برتر ۷ روز'),
('resetRate_delay', '86400', 'به روز رسانی رتبه ها هر'),
('resetRate_last', '1400856279', 'آخرین به روز رسانی رتبه ها');

-- --------------------------------------------------------

--
-- Table structure for table `share_projects`
--

CREATE TABLE IF NOT EXISTS `share_projects` (
  `prj_id` int(11) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`prj_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `twitts`
--

CREATE TABLE IF NOT EXISTS `twitts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `ref_page` varchar(20) DEFAULT NULL,
  `ref_id` int(11) DEFAULT NULL,
  `text` text NOT NULL,
  `reply_id` int(11) unsigned DEFAULT NULL,
  `blocked` tinyint(1) NOT NULL DEFAULT '0',
  `verified` int(2) NOT NULL,
  `last_reply` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `reply_id` (`reply_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `twitts`
--

INSERT INTO `twitts` (`id`, `user_id`, `ref_page`, `ref_id`, `text`, `reply_id`, `blocked`, `verified`, `last_reply`, `dateline`) VALUES
(1, 8, 'twitt', 0, 'سلام به همگی ', 0, 0, 1, 1432569890, 1432569890);

-- --------------------------------------------------------

--
-- Table structure for table `users_sub`
--

CREATE TABLE IF NOT EXISTS `users_sub` (
  `id` int(11) unsigned NOT NULL,
  `usergroup` enum('Administrator','Worker','User','Agency','Admin','Bookkeeper','System','Both') NOT NULL,
  `reg_date` int(10) unsigned NOT NULL DEFAULT '0',
  `rank` float NOT NULL,
  `rankers` int(11) NOT NULL,
  `rate` int(11) NOT NULL,
  `finished_projects` int(11) NOT NULL,
  `running_projects` int(11) NOT NULL,
  `rejected_projects` int(11) NOT NULL,
  `presenter_id` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `feature` varchar(60) NOT NULL DEFAULT '',
  `special_type` enum('None','Special','Employ') NOT NULL DEFAULT 'None',
  `special_expire_date` int(11) NOT NULL,
  `verified` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_sub`
--

INSERT INTO `users_sub` (`id`, `usergroup`, `reg_date`, `rank`, `rankers`, `rate`, `finished_projects`, `running_projects`, `rejected_projects`, `presenter_id`, `level`, `feature`, `special_type`, `special_expire_date`, `verified`) VALUES
(0, 'User', 1429429952, 0, 0, 1, 0, 0, 0, 0, 0, '', 'None', 0, 2),
(2, 'Administrator', 1336358887, 0, 0, 1, 0, -9, 9, 0, 0, '', 'None', 0, 2),
(8, 'Worker', 0, 9, 2, 1, 4, 0, 1, 0, 0, '', 'None', 0, 2),
(9, 'User', 0, 0, 0, 1, 4, -14, 20, 0, 0, '', 'None', 0, 2),
(10, 'Agency', 0, 0, 0, 2, 0, -1, 1, 0, 0, '', 'None', 0, 2),
(50, 'Administrator', 0, 0, 0, 1, 0, 0, 0, 0, 0, '', 'None', 0, 2),
(51, 'Admin', 1401727356, 0, 0, 1, 0, 0, 0, 0, 0, '', 'None', 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `user_visit`
--

CREATE TABLE IF NOT EXISTS `user_visit` (
  `ip` varchar(16) DEFAULT NULL,
  `user_id` int(11) unsigned DEFAULT NULL,
  `page` varchar(50) DEFAULT NULL,
  `date` int(11) unsigned NOT NULL,
  UNIQUE KEY `user_id_2` (`user_id`,`page`,`date`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_visit`
--

INSERT INTO `user_visit` (`ip`, `user_id`, `page`, `date`) VALUES
('5.239.97.197', 50, 'manage-projects', 1432433583),
('5.239.97.197', 50, 'manage-reviewrequests', 1432433590),
('5.239.97.197', 50, 'manage-accounting', 1432433593),
('5.239.97.197', 50, 'manage-messages', 1432433598),
('5.239.97.197', 50, 'manage-smses', 1432433599),
('5.239.97.197', 50, 'manage-userlevel', 1432433600),
('5.239.97.197', 50, 'panel', 1432433619),
('5.239.97.197', 50, 'panel', 1432433649),
('5.239.97.197', 50, 'home', 1432433650),
('5.239.103.232', 50, 'panel', 1432440375),
('5.239.103.232', 50, 'home', 1432440376),
('5.239.103.232', 50, 'manage-users-online', 1432440380),
('185.11.89.35', NULL, 'home', 1432465137),
('185.11.89.35', NULL, 'home_media_icons.png', 1432465139),
('185.11.89.35', NULL, 'home', 1432465452),
('65.49.68.204', NULL, 'home', 1432473477),
('65.49.68.204', NULL, 'home_media_icons.png', 1432473478),
('65.49.68.204', NULL, 'home', 1432473479),
('65.49.68.204', NULL, 'panel', 1432473739),
('65.49.68.204', NULL, 'panel', 1432473745),
('65.49.68.204', 9, 'panel', 1432473746),
('65.49.68.204', 9, 'success-login', 1432473746),
('65.49.68.204', 9, 'success-login', 1432473747),
('65.49.68.204', 9, 'panel', 1432473747),
('65.49.68.204', 9, 'home', 1432473749),
('65.49.68.204', 9, 'projects_all_9', 1432473752),
('65.49.68.204', 9, 'submit-project', 1432473755),
('65.49.68.204', 9, 'projects_all_9', 1432473768),
('65.49.68.204', 9, 'add-credit', 1432473773),
('65.49.68.204', 9, 'add-credit', 1432473779),
('185.11.89.35', 9, 'home', 1432475210),
('185.11.89.35', 9, 'home_media_icons.png', 1432475210),
('185.11.89.35', 9, 'home', 1432475211),
('185.11.89.35', 9, 'home', 1432475212),
('185.11.89.35', 9, 'home', 1432475214),
('185.11.89.35', 9, 'panel', 1432475215),
('185.11.89.35', 9, 'home', 1432475216),
('185.11.89.35', 9, 'home', 1432475217),
('185.11.89.35', 9, 'submit-project', 1432475576),
('185.11.89.35', 9, 'home', 1432475576),
('185.11.89.35', 9, 'home', 1432475577),
('65.49.68.204', NULL, 'home', 1432489016),
('65.49.68.204', NULL, 'home_media_icons.png', 1432489020),
('65.49.68.204', NULL, 'home', 1432489044),
('65.49.68.204', NULL, 'panel', 1432489051),
('65.49.68.204', NULL, 'register', 1432489087),
('65.49.68.204', NULL, 'login-denied', 1432489214),
('65.49.68.204', NULL, 'home', 1432489215),
('65.49.68.204', NULL, 'home', 1432489215),
('65.49.68.204', NULL, 'home', 1432489215),
('65.49.68.204', NULL, 'panel', 1432490284),
('65.49.68.204', NULL, 'home', 1432490285),
('65.49.68.204', NULL, 'panel', 1432490291),
('65.49.68.204', 8, 'success-login', 1432490291),
('65.49.68.204', 8, 'panel', 1432490291),
('65.49.68.204', 8, 'success-login', 1432490292),
('65.49.68.204', 8, 'panel', 1432490293),
('65.49.68.204', 8, 'success-login', 1432490294),
('65.49.68.204', 8, 'panel', 1432490295),
('65.49.68.204', 8, 'success-login', 1432490295),
('65.49.68.204', 8, 'panel', 1432490297),
('65.49.68.204', 8, 'projects_open', 1432490548),
('65.49.68.204', 8, 'accounting', 1432490621),
('65.49.68.204', 8, 'bids', 1432490801),
('185.11.89.35', 8, 'home', 1432499073),
('185.11.89.35', 8, 'home_media_icons.png', 1432499073),
('185.11.89.35', 8, 'home', 1432499074),
('185.11.89.35', 8, 'home', 1432499075),
('185.11.89.35', 8, 'home', 1432499077),
('185.11.89.35', 8, 'home', 1432499081),
('185.11.89.35', 8, 'panel', 1432499125),
('185.11.89.35', 8, 'home', 1432499125),
('185.11.89.35', 8, 'home', 1432499126),
('185.11.89.35', 8, 'panel_logout', 1432499131),
('185.11.89.35', NULL, 'success-logout', 1432499131),
('185.11.89.35', NULL, 'home', 1432499132),
('185.11.89.35', NULL, 'home', 1432499132),
('185.11.89.35', NULL, 'home', 1432499133),
('185.11.89.35', NULL, 'home', 1432499137),
('185.11.89.35', NULL, 'home_media_icons.png', 1432499137),
('185.11.89.35', NULL, 'home', 1432499138),
('185.11.89.35', NULL, 'login-denied', 1432499140),
('185.11.89.35', NULL, 'home', 1432499142),
('185.11.89.35', NULL, 'home', 1432499142),
('185.11.89.35', NULL, 'home', 1432499142),
('185.11.89.35', NULL, 'panel', 1432499143),
('185.11.89.35', NULL, 'home', 1432499143),
('185.11.89.35', NULL, 'panel', 1432499150),
('185.11.89.35', 9, 'success-login', 1432499150),
('185.11.89.35', 9, 'panel', 1432499150),
('185.11.89.35', 9, 'home', 1432499151),
('185.11.89.35', 9, 'projects_all_9', 1432499154),
('185.11.89.35', 9, 'submit-project', 1432499156),
('185.11.89.35', 9, 'home', 1432499156),
('185.11.89.35', 9, 'home', 1432499157),
('185.11.89.35', 9, 'send-message', 1432499166),
('65.49.68.204', 9, 'user_9', 1432500133),
('65.49.68.204', 9, 'home', 1432500134),
('65.49.68.204', 9, 'panel', 1432500177),
('62.212.68.156', NULL, 'home', 1432500238),
('54.88.252.37', NULL, 'home', 1432501625),
('52.6.159.125', NULL, 'panel', 1432501659),
('52.4.93.78', NULL, 'home', 1432501660),
('54.88.252.37', NULL, 'panel', 1432501716),
('52.4.210.20', NULL, 'register', 1432501717),
('52.7.125.134', NULL, 'panel', 1432501719),
('52.4.210.20', NULL, 'home', 1432501720),
('52.0.9.205', NULL, '', 1432501857),
('54.88.252.37', NULL, 'panel', 1432501857),
('52.7.14.160', NULL, 'register', 1432501858),
('52.6.17.188', NULL, 'register', 1432501859),
('52.6.123.202', NULL, 'panel', 1432501861),
('52.6.17.188', NULL, 'panel', 1432501863),
('52.6.159.125', NULL, 'panel', 1432501864),
('52.6.123.202', NULL, 'register', 1432501865),
('52.6.123.202', NULL, 'home', 1432501865),
('52.6.159.125', NULL, 'panel', 1432501929),
('54.86.233.50', NULL, 'panel', 1432501936),
('54.86.233.50', NULL, '', 1432501936),
('52.6.123.202', NULL, 'register', 1432501937),
('52.6.123.202', NULL, 'panel', 1432501937),
('52.6.123.202', NULL, '', 1432501937),
('52.6.123.202', NULL, 'register', 1432501938),
('54.86.233.50', NULL, 'register', 1432501939),
('52.7.14.160', NULL, 'panel', 1432501939),
('52.4.210.20', NULL, 'register', 1432501942),
('52.4.210.20', NULL, 'panel', 1432501942),
('52.5.174.143', NULL, 'panel', 1432501943),
('52.7.125.134', NULL, 'register', 1432501946),
('52.6.159.125', NULL, '', 1432501949),
('52.4.93.78', NULL, 'panel', 1432501949),
('52.4.93.78', NULL, 'register', 1432501949),
('52.4.93.78', NULL, 'home', 1432501949),
('52.7.125.134', NULL, 'register', 1432501957),
('54.86.233.50', NULL, 'panel', 1432501958),
('52.6.159.125', NULL, 'register', 1432501994),
('52.4.210.20', NULL, 'panel', 1432501994),
('52.6.159.125', NULL, '', 1432501996),
('54.88.252.37', NULL, 'panel', 1432501997),
('54.88.252.37', NULL, 'register', 1432501997),
('54.88.252.37', NULL, 'panel', 1432501997),
('52.6.159.125', NULL, 'register', 1432501997),
('52.6.159.125', NULL, 'register', 1432501997),
('52.6.159.125', NULL, '', 1432501997),
('54.88.252.37', NULL, 'panel', 1432501998),
('54.88.252.37', NULL, 'panel', 1432501998),
('54.88.252.37', NULL, 'register', 1432501998),
('54.88.252.37', NULL, 'panel', 1432501999),
('52.6.17.188', NULL, 'register', 1432502000),
('52.5.174.143', NULL, 'register', 1432502000),
('54.88.252.37', NULL, 'panel', 1432502000),
('54.88.252.37', NULL, '', 1432502000),
('54.88.252.37', NULL, 'panel', 1432502000),
('52.0.179.182', NULL, 'panel', 1432502001),
('52.0.179.182', NULL, '', 1432502001),
('52.0.179.182', NULL, 'register', 1432502001),
('52.6.159.125', NULL, 'panel', 1432502001),
('52.6.159.125', NULL, 'register', 1432502001),
('52.6.159.125', NULL, 'register', 1432502001),
('52.4.210.20', NULL, 'register', 1432502003),
('52.6.159.125', NULL, 'panel', 1432502003),
('52.6.159.125', NULL, 'home', 1432502003),
('52.0.9.205', NULL, '', 1432502003),
('52.0.9.205', NULL, 'panel', 1432502003),
('52.0.9.205', NULL, 'register', 1432502003),
('52.6.159.125', NULL, 'panel', 1432502008),
('54.86.233.50', NULL, '', 1432502008),
('54.86.233.50', NULL, 'register', 1432502008),
('54.86.233.50', NULL, 'panel', 1432502008),
('52.4.93.78', NULL, '', 1432502017),
('52.4.93.78', NULL, 'register', 1432502017),
('52.4.210.20', NULL, 'register', 1432502017),
('54.88.252.37', NULL, 'panel', 1432502021),
('54.86.233.50', NULL, 'register', 1432502021),
('52.7.14.160', NULL, 'panel', 1432502021),
('52.4.93.78', NULL, 'register', 1432502022),
('52.4.93.78', NULL, '', 1432502022),
('52.4.93.78', NULL, 'register', 1432502022),
('52.6.17.188', NULL, '', 1432502022),
('52.6.17.188', NULL, 'panel', 1432502022),
('52.6.17.188', NULL, 'panel', 1432502022),
('52.4.210.20', NULL, 'register', 1432502022),
('52.4.210.20', NULL, 'panel', 1432502022),
('52.4.210.20', NULL, 'register', 1432502022),
('52.6.17.188', NULL, 'panel', 1432502023),
('52.6.17.188', NULL, 'register', 1432502023),
('52.4.210.20', NULL, '', 1432502023),
('52.4.210.20', NULL, 'register', 1432502023),
('52.4.210.20', NULL, 'panel', 1432502023),
('52.5.174.143', NULL, 'panel', 1432502024),
('52.5.174.143', NULL, 'panel', 1432502026),
('52.5.174.143', NULL, 'register', 1432502026),
('52.5.174.143', NULL, 'panel', 1432502026),
('52.7.172.163', NULL, '', 1432502027),
('52.7.172.163', NULL, 'register', 1432502027),
('52.7.172.163', NULL, 'panel', 1432502027),
('52.6.123.202', NULL, 'register', 1432502027),
('52.6.123.202', NULL, '', 1432502027),
('52.5.174.143', NULL, 'register', 1432502027),
('52.5.174.143', NULL, 'register', 1432502027),
('52.5.174.143', NULL, 'register', 1432502027),
('52.7.172.163', NULL, 'panel', 1432502028),
('52.7.172.163', NULL, 'panel', 1432502028),
('52.7.172.163', NULL, 'panel', 1432502028),
('52.6.123.202', NULL, '', 1432502029),
('52.6.123.202', NULL, 'panel', 1432502029),
('52.6.123.202', NULL, '', 1432502029),
('52.0.179.182', NULL, 'register', 1432502029),
('52.0.179.182', NULL, 'panel', 1432502029),
('52.7.172.163', NULL, 'register', 1432502029),
('52.7.172.163', NULL, 'register', 1432502029),
('52.7.172.163', NULL, 'register', 1432502029),
('52.0.9.205', NULL, 'panel', 1432502029),
('52.5.174.143', NULL, 'panel', 1432502029),
('52.5.174.143', NULL, 'panel', 1432502029),
('52.5.174.143', NULL, '', 1432502029),
('52.7.125.134', NULL, '', 1432502029),
('52.7.125.134', NULL, 'register', 1432502029),
('54.88.252.37', NULL, '', 1432502030),
('54.88.252.37', NULL, 'register', 1432502030),
('54.88.252.37', NULL, 'register', 1432502030),
('54.86.233.50', NULL, 'panel', 1432502030),
('54.86.233.50', NULL, 'panel', 1432502030),
('54.86.233.50', NULL, '', 1432502030),
('52.6.159.125', NULL, '', 1432502030),
('52.6.159.125', NULL, 'panel', 1432502030),
('52.6.159.125', NULL, 'panel', 1432502030),
('52.6.123.202', NULL, 'register', 1432502030),
('52.7.14.160', NULL, 'panel', 1432502030),
('52.7.14.160', NULL, '', 1432502030),
('52.7.14.160', NULL, 'panel', 1432502030),
('54.86.233.50', NULL, 'register', 1432502031),
('52.4.93.78', NULL, 'register', 1432502031),
('52.4.93.78', NULL, 'panel', 1432502031),
('52.6.159.125', NULL, 'panel', 1432502031),
('52.6.17.188', NULL, 'register', 1432502031),
('52.4.210.20', NULL, 'register', 1432502031),
('52.4.210.20', NULL, 'panel', 1432502031),
('52.7.14.160', NULL, 'register', 1432502031),
('52.7.14.160', NULL, 'home', 1432502031),
('52.7.14.160', NULL, 'panel', 1432502031),
('52.7.125.134', NULL, 'register', 1432502035),
('54.88.252.37', NULL, '', 1432502035),
('52.4.93.78', NULL, 'panel', 1432502036),
('52.7.125.134', NULL, 'register', 1432502037),
('52.4.93.78', NULL, 'register', 1432502038),
('52.4.93.78', NULL, '', 1432502038),
('52.4.93.78', NULL, 'register', 1432502038),
('52.6.123.202', NULL, 'register', 1432502038),
('52.6.123.202', NULL, 'register', 1432502038),
('52.6.123.202', NULL, 'register', 1432502038),
('52.7.172.163', NULL, 'panel', 1432502038),
('52.7.172.163', NULL, 'panel', 1432502038),
('52.0.9.205', NULL, 'panel', 1432502038),
('52.0.9.205', NULL, 'register', 1432502038),
('52.0.179.182', NULL, '', 1432502038),
('52.0.179.182', NULL, 'panel', 1432502038),
('52.0.9.205', NULL, 'panel', 1432502038),
('52.0.179.182', NULL, 'panel', 1432502038),
('52.5.174.143', NULL, 'register', 1432502038),
('52.5.174.143', NULL, 'panel', 1432502038),
('52.5.174.143', NULL, 'register', 1432502038),
('54.86.233.50', NULL, 'register', 1432502038),
('54.86.233.50', NULL, 'panel', 1432502038),
('54.86.233.50', NULL, 'panel', 1432502038),
('52.6.159.125', NULL, 'panel', 1432502038),
('52.7.14.160', NULL, '', 1432502039),
('52.7.14.160', NULL, 'register', 1432502039),
('52.7.14.160', NULL, '', 1432502039),
('52.0.9.205', NULL, 'panel', 1432502039),
('52.0.179.182', NULL, 'panel', 1432502039),
('52.0.9.205', NULL, 'register', 1432502039),
('52.5.174.143', NULL, 'panel', 1432502039),
('52.7.125.134', NULL, 'register', 1432502039),
('52.7.125.134', NULL, 'register', 1432502039),
('52.7.125.134', NULL, '', 1432502039),
('52.4.210.20', NULL, 'register', 1432502039),
('52.4.210.20', NULL, '', 1432502039),
('54.86.233.50', NULL, 'panel', 1432502039),
('52.7.14.160', NULL, 'panel', 1432502040),
('54.88.252.37', NULL, '', 1432502040),
('54.88.252.37', NULL, 'register', 1432502040),
('54.88.252.37', NULL, 'register', 1432502042),
('54.88.252.37', NULL, '', 1432502042),
('54.88.252.37', NULL, 'panel', 1432502042),
('54.88.252.37', NULL, 'panel', 1432502043),
('54.88.252.37', NULL, '', 1432502043),
('54.88.252.37', NULL, 'panel', 1432502043),
('52.6.17.188', NULL, 'panel', 1432502043),
('52.6.17.188', NULL, 'register', 1432502043),
('52.6.17.188', NULL, 'panel', 1432502043),
('52.6.123.202', NULL, 'register', 1432502043),
('52.6.123.202', NULL, 'register', 1432502043),
('52.6.123.202', NULL, 'panel', 1432502043),
('52.0.9.205', NULL, 'register', 1432502044),
('52.7.172.163', NULL, 'register', 1432502044),
('52.0.9.205', NULL, 'panel', 1432502044),
('52.0.9.205', NULL, 'register', 1432502044),
('52.7.172.163', NULL, 'register', 1432502044),
('52.0.179.182', NULL, 'register', 1432502044),
('52.0.179.182', NULL, 'panel', 1432502044),
('52.0.179.182', NULL, 'register', 1432502044),
('52.7.172.163', NULL, 'register', 1432502044),
('54.88.252.37', NULL, 'register', 1432502044),
('54.88.252.37', NULL, 'panel', 1432502044),
('54.88.252.37', NULL, 'register', 1432502044),
('52.5.174.143', NULL, '', 1432502044),
('52.5.174.143', NULL, 'panel', 1432502044),
('52.6.159.125', NULL, 'panel', 1432502044),
('52.5.174.143', NULL, 'panel', 1432502044),
('52.6.159.125', NULL, '', 1432502044),
('52.6.159.125', NULL, 'register', 1432502044),
('54.86.233.50', NULL, '', 1432502044),
('52.6.17.188', NULL, 'panel', 1432502044),
('52.6.17.188', NULL, 'register', 1432502044),
('52.6.17.188', NULL, 'register', 1432502044),
('52.6.123.202', NULL, 'panel', 1432502044),
('52.6.123.202', NULL, '', 1432502044),
('52.7.14.160', NULL, 'panel', 1432502044),
('52.7.14.160', NULL, 'panel', 1432502044),
('52.7.14.160', NULL, 'register', 1432502044),
('52.7.125.134', NULL, '', 1432502045),
('52.7.125.134', NULL, 'panel', 1432502045),
('52.0.9.205', NULL, '', 1432502045),
('52.7.125.134', NULL, 'panel', 1432502045),
('52.0.9.205', NULL, 'register', 1432502045),
('52.5.174.143', NULL, '', 1432502045),
('54.88.252.37', NULL, 'register', 1432502045),
('54.88.252.37', NULL, '', 1432502045),
('52.6.159.125', NULL, 'panel', 1432502045),
('54.88.252.37', NULL, 'register', 1432502045),
('52.6.159.125', NULL, 'register', 1432502045),
('52.6.159.125', NULL, 'panel', 1432502045),
('52.5.174.143', NULL, 'panel', 1432502045),
('52.4.210.20', NULL, 'panel', 1432502045),
('52.4.210.20', NULL, 'panel', 1432502045),
('52.4.210.20', NULL, 'register', 1432502045),
('52.6.17.188', NULL, 'register', 1432502045),
('52.7.14.160', NULL, 'register', 1432502045),
('52.7.14.160', NULL, 'panel', 1432502045),
('52.7.14.160', NULL, 'register', 1432502045),
('52.7.125.134', NULL, '', 1432502046),
('52.7.125.134', NULL, 'register', 1432502046),
('54.88.252.37', NULL, 'panel', 1432502046),
('52.6.159.125', NULL, 'register', 1432502046),
('52.6.159.125', NULL, '', 1432502046),
('52.6.159.125', NULL, '', 1432502046),
('54.88.252.37', NULL, 'panel', 1432502046),
('52.4.210.20', NULL, 'panel', 1432502046),
('52.4.210.20', NULL, 'panel', 1432502046),
('54.88.252.37', NULL, 'register', 1432502046),
('52.7.14.160', NULL, 'register', 1432502046),
('52.7.14.160', NULL, '', 1432502046),
('52.6.159.125', NULL, '', 1432502047),
('52.6.159.125', NULL, 'panel', 1432502047),
('52.6.159.125', NULL, 'panel', 1432502047),
('54.88.252.37', NULL, 'register', 1432502047),
('54.88.252.37', NULL, 'register', 1432502047),
('54.88.252.37', NULL, 'register', 1432502047),
('52.6.159.125', NULL, 'panel', 1432502048),
('54.88.252.37', NULL, 'panel', 1432502048),
('54.88.252.37', NULL, 'register', 1432502048),
('52.6.123.202', NULL, 'register', 1432502052),
('52.6.123.202', NULL, 'panel', 1432502052),
('52.6.17.188', NULL, 'register', 1432502052),
('52.6.123.202', NULL, 'panel', 1432502052),
('52.6.17.188', NULL, 'panel', 1432502052),
('52.4.93.78', NULL, '', 1432502053),
('52.4.93.78', NULL, 'panel', 1432502053),
('52.4.93.78', NULL, 'register', 1432502053),
('52.7.172.163', NULL, 'panel', 1432502053),
('52.7.172.163', NULL, 'panel', 1432502053),
('52.7.172.163', NULL, '', 1432502053),
('52.0.179.182', NULL, 'panel', 1432502053),
('52.0.9.205', NULL, 'register', 1432502053),
('52.0.9.205', NULL, '', 1432502053),
('52.0.9.205', NULL, '', 1432502053),
('52.6.159.125', NULL, '', 1432502053),
('52.6.159.125', NULL, 'home', 1432502053),
('52.5.174.143', NULL, 'panel', 1432502053),
('52.5.174.143', NULL, 'panel', 1432502053),
('52.5.174.143', NULL, 'register', 1432502053),
('54.86.233.50', NULL, 'panel', 1432502053),
('54.86.233.50', NULL, 'register', 1432502053),
('54.86.233.50', NULL, '', 1432502053),
('54.88.252.37', NULL, 'register', 1432502054),
('54.88.252.37', NULL, 'register', 1432502054),
('52.7.14.160', NULL, 'panel', 1432502054),
('52.7.14.160', NULL, 'panel', 1432502054),
('52.7.14.160', NULL, '', 1432502054),
('52.7.125.134', NULL, 'panel', 1432502054),
('52.7.172.163', NULL, 'panel', 1432502054),
('52.7.172.163', NULL, 'register', 1432502054),
('52.5.174.143', NULL, 'register', 1432502054),
('54.86.233.50', NULL, 'register', 1432502054),
('54.86.233.50', NULL, '', 1432502054),
('52.4.210.20', NULL, 'panel', 1432502054),
('52.4.210.20', NULL, '', 1432502054),
('52.7.14.160', NULL, 'panel', 1432502055),
('52.6.17.188', NULL, 'register', 1432502056),
('52.6.17.188', NULL, 'register', 1432502056),
('67.229.128.103', NULL, 'home', 1432509522),
('66.249.67.1', NULL, 'home', 1432524616),
('185.11.89.35', NULL, 'home', 1432536037),
('185.11.89.35', NULL, 'home_media_icons.png', 1432536050),
('77.75.79.11', NULL, 'panel', 1432536549),
('65.49.68.204', NULL, 'home', 1432539041),
('65.49.68.204', NULL, 'home_media_icons.png', 1432539043),
('65.49.68.204', NULL, 'home', 1432539093),
('185.11.89.35', NULL, 'home', 1432539849),
('185.11.89.35', NULL, 'home', 1432539850),
('185.11.89.35', NULL, 'home_media_icons.png', 1432539850),
('185.11.89.35', NULL, 'panel', 1432539866),
('185.11.89.35', NULL, 'home', 1432539869),
('181.61.83.30', NULL, 'home', 1432540210),
('65.49.68.204', NULL, 'home', 1432540930),
('65.49.68.204', NULL, 'home_media_icons.png', 1432540933),
('65.49.68.204', NULL, 'home', 1432541277),
('65.49.68.204', NULL, 'home', 1432543177),
('65.49.68.204', NULL, 'home_media_icons.png', 1432543178),
('66.249.93.131', NULL, 'home', 1432543359),
('66.249.93.251', NULL, 'home', 1432543359),
('65.49.68.204', NULL, 'home', 1432543463),
('66.249.93.254', NULL, 'home', 1432543547),
('66.249.93.131', NULL, 'home', 1432543547),
('180.76.15.15', NULL, 'home', 1432545076),
('66.249.67.1', NULL, 'home', 1432545933),
('185.11.89.35', NULL, 'home', 1432547585),
('185.11.89.35', NULL, 'home_media_icons.png', 1432547602),
('185.11.89.35', NULL, 'home', 1432547904),
('185.11.89.35', NULL, 'panel', 1432550102),
('185.11.89.35', NULL, 'home', 1432550103),
('185.11.89.35', NULL, 'panel', 1432550107),
('185.11.89.35', 9, 'success-login', 1432550107),
('185.11.89.35', 9, 'panel', 1432550107),
('185.11.89.35', 9, 'home', 1432550113),
('66.249.67.23', NULL, 'home', 1432550156),
('185.11.89.35', 9, 'home', 1432550196),
('185.11.89.35', 9, 'home_media_icons.png', 1432550197),
('185.11.89.35', 9, 'home', 1432550205),
('185.11.89.35', 9, 'home_media_icons.png', 1432550205),
('185.11.89.35', 9, 'home', 1432550211),
('185.11.89.35', 9, 'home_media_icons.png', 1432550211),
('185.11.89.33', NULL, 'home', 1432566359),
('185.11.89.33', NULL, 'home_media_icons.png', 1432566360),
('185.11.89.33', NULL, 'home', 1432566404),
('185.11.89.33', NULL, 'home', 1432566427),
('185.11.89.33', NULL, 'home_media_icons.png', 1432566427),
('185.11.89.33', NULL, 'home', 1432566429),
('185.11.89.33', NULL, 'home', 1432566440),
('185.11.89.33', NULL, 'home', 1432566440),
('185.11.89.33', NULL, 'login-denied', 1432566477),
('185.11.89.33', NULL, 'home', 1432566477),
('185.11.89.33', NULL, 'home', 1432566477),
('185.11.89.33', NULL, 'home', 1432566478),
('185.11.89.33', NULL, 'panel', 1432566484),
('185.11.89.33', NULL, 'home', 1432566484),
('185.11.89.33', NULL, 'panel', 1432566487),
('185.11.89.33', 9, 'success-login', 1432566487),
('185.11.89.33', 9, 'panel', 1432566488),
('185.11.89.33', 9, 'home', 1432566488),
('185.11.89.33', 9, 'home', 1432566489),
('185.11.89.33', 9, 'submit-project', 1432566539),
('185.11.89.33', 9, 'project_44', 1432566543),
('185.11.89.33', 9, 'home', 1432566543),
('185.11.89.33', 9, 'home', 1432566544),
('185.11.89.33', NULL, 'home', 1432566593),
('185.11.89.33', NULL, 'home_media_icons.png', 1432566595),
('185.11.89.33', NULL, 'home', 1432566617),
('185.11.89.33', NULL, 'login-denied', 1432566627),
('185.11.89.33', NULL, 'home', 1432566634),
('185.11.89.33', NULL, 'home', 1432566635),
('185.11.89.33', NULL, 'home', 1432566635),
('185.11.89.33', NULL, 'home', 1432566635),
('185.11.89.33', NULL, 'home', 1432566635),
('185.11.89.33', NULL, 'home', 1432566635),
('185.11.89.33', NULL, 'panel', 1432566642),
('185.11.89.33', NULL, 'panel', 1432566654),
('185.11.89.33', NULL, 'panel', 1432566675),
('185.11.89.33', 8, 'success-login', 1432566675),
('185.11.89.33', 8, 'panel', 1432566676),
('185.11.89.33', 8, 'home', 1432566676),
('185.11.89.33', 8, 'home', 1432566677),
('185.11.89.33', 8, 'projects_open', 1432566682),
('185.11.89.33', 8, 'project_44', 1432566692),
('185.11.89.33', 8, 'project_44', 1432566707),
('185.11.89.33', 8, 'project_44', 1432566727),
('185.11.89.33', 8, 'home', 1432566728),
('185.11.89.33', 8, 'home', 1432566729),
('185.11.89.33', 8, 'add-credit', 1432566743),
('185.11.89.33', 8, 'add-credit', 1432566753),
('185.11.89.33', 8, 'project_44', 1432566766),
('185.11.89.33', 8, 'project_44', 1432566774),
('185.11.89.33', 8, 'home', 1432566777),
('185.11.89.33', 8, 'home', 1432566778),
('185.11.89.33', 8, 'add-credit', 1432566779),
('185.11.89.33', 8, 'add-credit', 1432566784),
('185.11.89.33', 9, 'messages_inbox', 1432566830),
('185.11.89.33', 9, 'home', 1432566854),
('185.11.89.33', 8, 'response', 1432566885),
('185.11.89.33', 8, 'home', 1432566886),
('185.11.89.33', 8, 'home', 1432566887),
('185.11.89.33', 9, 'home', 1432566887),
('185.11.89.33', 9, 'home_media_icons.png', 1432566888),
('185.11.89.33', 9, 'home', 1432566888),
('185.11.89.33', 8, 'panel', 1432566894),
('185.11.89.33', 8, 'home', 1432566898),
('185.11.89.33', 8, 'projects_open', 1432566899),
('185.11.89.33', 8, 'home', 1432566899),
('185.11.89.33', 8, 'project_44', 1432566991),
('185.11.89.33', 9, 'panel', 1432566995),
('185.11.89.33', 9, 'home', 1432566997),
('185.11.89.33', 8, 'project_44', 1432566999),
('185.11.89.33', 8, 'project_44', 1432567007),
('185.11.89.33', 8, 'home', 1432567007),
('185.11.89.33', 8, 'home', 1432567008),
('185.11.89.33', 9, 'user-list_worker', 1432567022),
('185.11.89.33', 9, 'user-list_worker', 1432567035),
('185.11.89.33', 9, 'event_4', 1432567037),
('185.11.89.33', 9, 'ajax-pages', 1432567039),
('185.11.89.33', 9, 'projects_all_9', 1432567047),
('185.11.89.33', 9, 'project_44', 1432567051),
('185.11.89.33', 9, 'accept-bid_1', 1432567061),
('185.11.89.33', 9, 'add-credit', 1432567063),
('185.11.89.33', 9, 'home', 1432567063),
('185.11.89.33', 9, 'home', 1432567064),
('185.11.89.33', 9, 'add-credit', 1432567067),
('185.11.89.33', 9, 'projects_all_9', 1432567121),
('185.11.89.33', 9, 'project_44', 1432567122),
('185.11.89.33', 9, 'send-message_8_44', 1432567135),
('185.11.89.33', 9, 'accept-bid_1', 1432567142),
('185.11.89.33', 9, 'add-credit', 1432567148),
('185.11.89.33', 9, 'home', 1432567149),
('185.11.89.33', 9, 'home', 1432567150),
('185.11.89.33', 9, 'add-credit', 1432567151),
('185.11.89.33', 9, 'response', 1432567202),
('185.11.89.33', 9, 'accept-bid_1_AB1', 1432567203),
('185.11.89.33', 9, 'project_44', 1432567204),
('185.11.89.33', 9, 'home', 1432567205),
('185.11.89.33', 8, 'event_7', 1432567210),
('185.11.89.33', 9, 'event_8', 1432567210),
('185.11.89.33', 9, 'project_44', 1432567211),
('185.11.89.33', 9, 'home', 1432567212),
('185.11.89.33', 8, 'project_44', 1432567213),
('185.11.89.33', 8, 'home', 1432567214),
('185.11.89.33', 8, 'project_44', 1432567231),
('185.11.89.33', 8, 'home', 1432567232),
('185.11.89.33', 9, 'panel', 1432567407),
('185.11.89.33', 9, 'home', 1432567408),
('185.11.89.33', 9, 'home', 1432567409),
('185.11.89.33', 9, 'user_9', 1432567425),
('185.11.89.33', 9, 'home', 1432567426),
('185.11.89.33', 9, 'home', 1432567427),
('185.11.89.33', 9, 'panel', 1432567447),
('185.11.89.33', 9, 'home', 1432567448),
('185.11.89.33', 9, 'projects_all_9', 1432567552),
('185.11.89.33', 9, 'submit-project', 1432567555),
('185.11.89.33', 9, 'home', 1432567555),
('185.11.89.33', 9, 'home', 1432567556),
('185.11.89.33', 9, 'send-message', 1432567591),
('185.11.89.33', NULL, 'home', 1432568146),
('185.11.89.33', NULL, 'home_media_icons.png', 1432568147),
('185.11.89.33', 9, 'submit-project', 1432568416),
('185.11.89.33', 9, 'home', 1432568416),
('185.11.89.33', 9, 'home', 1432568420),
('185.11.89.33', 9, 'home', 1432568438),
('185.11.89.33', 9, 'home', 1432568445),
('185.11.89.33', 9, 'home', 1432568446),
('185.11.89.33', 9, 'user-list_worker', 1432568458),
('185.11.89.33', 9, 'home', 1432569176),
('185.11.89.33', 9, 'panel_logout', 1432569417),
('185.11.89.33', NULL, 'success-logout', 1432569418),
('185.11.89.33', NULL, 'home', 1432569418),
('185.11.89.33', NULL, 'home', 1432569419),
('185.11.89.33', NULL, 'home', 1432569419),
('185.11.89.33', NULL, 'home', 1432569423),
('185.11.89.33', NULL, 'home_media_icons.png', 1432569426),
('185.11.89.33', NULL, 'panel', 1432569426),
('185.11.89.33', NULL, 'home', 1432569428),
('185.11.89.33', NULL, 'panel', 1432569445),
('185.11.89.33', 8, 'success-login', 1432569445),
('185.11.89.33', 8, 'panel', 1432569445),
('185.11.89.33', 8, 'home', 1432569447),
('185.11.89.33', 8, 'home', 1432569448),
('185.11.89.33', 8, 'event_6', 1432569455),
('185.11.89.33', 8, 'event_6', 1432569456),
('185.11.89.33', 8, 'home', 1432569456),
('185.11.89.33', 8, 'project_44', 1432569460),
('185.11.89.33', 8, 'panel', 1432569464),
('185.11.89.33', 8, 'home', 1432569464),
('185.11.89.33', 8, 'home', 1432569468),
('185.11.89.33', 8, 'projects_open', 1432569477),
('185.11.89.33', 8, 'projects_open', 1432569651),
('185.11.89.33', 8, 'projects_all_8', 1432569676),
('185.11.89.33', 8, 'project_44', 1432569677),
('185.11.89.33', 8, 'projects_open', 1432569682),
('185.11.89.33', 8, 'panel', 1432569875),
('185.11.89.33', 8, 'home', 1432569876),
('185.11.89.33', 8, 'home', 1432569877),
('185.11.89.33', 8, 'user_8', 1432569921),
('185.11.89.33', 8, 'home', 1432569923),
('185.11.89.33', 8, 'home', 1432569924),
('185.11.89.33', 8, 'home', 1432570447),
('185.11.89.33', 8, 'home_media_icons.png', 1432570447),
('185.11.89.33', 8, 'home', 1432570456),
('185.11.89.33', NULL, 'panel', 1432570463),
('185.11.89.33', 8, 'projects_open', 1432570471),
('185.11.89.33', 8, 'projects_all_8', 1432570482),
('185.11.89.33', 8, 'project_44', 1432570483),
('185.11.89.33', 8, 'project_44', 1432570493),
('185.11.89.33', 8, 'project_44', 1432570496),
('185.11.89.33', 8, 'project_44', 1432570513),
('185.11.89.33', 8, 'project_44', 1432570514),
('185.11.89.33', 8, 'home', 1432570515),
('185.11.89.33', NULL, 'panel', 1432570529),
('185.11.89.33', 9, 'success-login', 1432570530),
('185.11.89.33', 9, 'panel', 1432570531),
('185.11.89.33', 9, 'home', 1432570532),
('185.11.89.33', 8, 'edit-settings', 1432570554),
('185.11.89.33', 8, 'edit-profile', 1432570561),
('185.11.89.33', 8, 'home', 1432570600),
('185.11.89.33', 8, 'home_media_icons.png', 1432570602),
('185.11.89.33', 8, 'home', 1432570602),
('5.239.21.74', NULL, 'home', 1432570733),
('5.239.21.74', NULL, 'home_media_icons.png', 1432570735),
('5.239.21.74', NULL, 'panel', 1432570743),
('5.239.21.74', NULL, 'home', 1432570743),
('5.239.21.74', NULL, 'home', 1432570744),
('5.239.21.74', NULL, 'panel', 1432570749),
('5.239.21.74', 8, 'success-login', 1432570750),
('5.239.21.74', 8, 'panel', 1432570750),
('5.239.21.74', 8, 'home', 1432570750),
('5.239.21.74', 8, 'home', 1432570751),
('5.239.21.74', 8, 'home', 1432570752),
('185.11.89.33', 8, 'panel', 1432570918),
('185.11.89.33', 8, 'home', 1432570919),
('185.11.89.33', 8, 'home', 1432570920),
('185.11.89.33', 8, 'user_8', 1432570961),
('185.11.89.33', 8, 'home', 1432570962),
('185.11.89.33', 8, 'home', 1432571095),
('185.11.89.33', 8, 'home_media_icons.png', 1432571095),
('185.11.89.33', 8, 'home', 1432571096),
('185.11.89.33', 8, 'home', 1432571101),
('185.11.89.33', 8, 'home', 1432571105),
('185.11.89.33', 8, 'home', 1432573408),
('185.11.89.33', 8, 'home_media_icons.png', 1432573408),
('185.11.89.33', 8, 'home', 1432573409),
('185.11.89.33', 8, 'home', 1432573414),
('185.11.89.33', 8, 'home', 1432573416),
('185.11.89.33', 8, 'home', 1432573418),
('5.239.21.74', 8, 'panel', 1432573474),
('5.239.21.74', 8, 'home', 1432573475),
('5.239.21.74', 8, 'home', 1432573481),
('5.239.21.74', 8, 'home_media_icons.png', 1432573482),
('185.11.89.33', 8, 'panel', 1432573526),
('185.11.89.33', 8, 'home', 1432573527),
('185.11.89.33', 8, 'home', 1432573529),
('5.239.21.74', 8, 'permission-denied', 1432573529),
('5.239.21.74', 8, 'home', 1432573530),
('5.239.21.74', 8, 'home', 1432573534),
('5.239.21.74', 8, 'home_media_icons.png', 1432573534),
('185.11.89.33', 8, 'home', 1432573806),
('185.11.89.33', 8, 'home', 1432573810),
('185.11.89.33', 8, 'home_media_icons.png', 1432573810),
('185.11.89.33', 8, 'home', 1432573811),
('2.191.216.250', NULL, 'bad-browser', 1432573812),
('185.11.89.33', 8, 'home', 1432573817),
('185.11.89.33', 8, 'home', 1432573820),
('185.11.89.33', 8, 'home_media_icons.png', 1432573820),
('185.11.89.33', 8, 'home', 1432573821),
('185.11.89.33', 8, 'home', 1432573836),
('185.11.89.33', 8, 'home_media_icons.png', 1432573836),
('185.11.89.33', 8, 'home', 1432573837),
('185.11.89.33', 8, 'home', 1432573838),
('5.239.21.74', 8, 'panel', 1432573873),
('5.239.21.74', 8, 'home', 1432573873),
('5.239.21.74', 8, 'home', 1432573875),
('185.11.89.33', 8, 'home', 1432573907),
('185.11.89.33', 8, 'home', 1432573978),
('185.11.89.33', 8, 'home_media_icons.png', 1432573979),
('185.11.89.33', 8, 'home', 1432573980),
('185.11.89.33', 8, 'home', 1432574127),
('185.11.89.33', 8, 'home_media_icons.png', 1432574128),
('185.11.89.33', 8, 'home', 1432574128),
('2.191.216.250', NULL, 'bad-browser', 1432574413),
('2.191.216.250', NULL, 'bad-browser', 1432575058),
('2.191.216.250', NULL, 'bad-browser', 1432575061),
('5.239.21.74', 8, 'report-chart', 1432578469),
('5.239.21.74', 8, 'home', 1432578469),
('5.239.21.74', 8, 'home', 1432578470),
('62.210.97.48', NULL, 'home', 1432579501),
('185.11.89.35', 9, 'home', 1432581699),
('185.11.89.35', 9, 'home_media_icons.png', 1432581700),
('104.255.64.50', NULL, 'home', 1432592307),
('151.240.152.166', NULL, 'home', 1432596116),
('151.240.152.166', NULL, 'login-denied', 1432596171),
('151.240.152.166', NULL, 'home', 1432596176),
('151.240.152.166', NULL, 'home', 1432596176),
('151.240.152.166', NULL, 'home', 1432596176),
('151.240.152.166', NULL, 'register', 1432596188),
('151.240.152.166', NULL, 'home', 1432596189),
('180.76.15.152', NULL, 'home', 1432601317),
('66.249.78.106', NULL, 'home', 1432612310),
('180.76.15.148', NULL, 'home', 1432618694),
('66.249.67.243', NULL, 'user_2', 1432620115),
('66.249.78.92', NULL, 'home', 1432620557),
('62.210.251.83', NULL, 'home', 1432636968),
('207.46.13.97', NULL, 'home', 1432637087),
('151.236.216.224', NULL, 'home', 1432643606),
('151.236.216.224', NULL, 'home_media_icons.png', 1432643608),
('108.171.215.188', NULL, 'home', 1432648817),
('108.171.215.188', NULL, 'home', 1432648819),
('185.11.89.35', NULL, 'home', 1432648964),
('185.11.89.35', NULL, 'home_media_icons.png', 1432648965),
('185.11.89.35', NULL, 'home', 1432648966),
('185.11.89.35', NULL, 'home', 1432648966),
('185.11.89.35', NULL, 'home', 1432648967),
('185.11.89.35', NULL, 'home', 1432649485),
('185.11.89.35', NULL, 'home_media_icons.png', 1432649485),
('185.11.89.35', NULL, 'home', 1432649486),
('94.153.11.229', NULL, 'home', 1432667364),
('94.153.11.229', NULL, 'home', 1432667364),
('180.76.15.7', NULL, 'home', 1432670461),
('157.55.39.5', NULL, 'home', 1432671225),
('64.246.165.200', NULL, 'home', 1432675757),
('64.246.165.190', NULL, 'home', 1432676554),
('64.246.165.180', NULL, 'home', 1432676899),
('194.126.181.138', NULL, 'home', 1432681286),
('66.249.67.5', NULL, 'home', 1432681902),
('68.180.228.97', NULL, 'home', 1432682623),
('46.229.170.197', NULL, 'bad-browser', 1432691210),
('220.181.108.86', NULL, 'home', 1432696916),
('66.249.67.243', NULL, 'home', 1432716634),
('23.27.44.164', NULL, 'home', 1432718991),
('23.27.44.164', NULL, 'home_media_icons.png', 1432718996),
('46.224.238.137', NULL, 'home', 1432719016),
('46.224.238.137', NULL, 'home_media_icons.png', 1432719029),
('185.11.89.35', NULL, 'home', 1432723944),
('185.11.89.35', NULL, 'home_media_icons.png', 1432723952),
('185.11.89.35', NULL, 'twitts', 1432724003),
('185.11.89.35', NULL, 'home', 1432724007),
('185.11.89.35', NULL, 'home', 1432724007),
('185.11.89.35', NULL, 'home', 1432724007),
('185.11.89.35', NULL, 'home', 1432724009),
('185.11.89.35', NULL, 'home', 1432724010),
('185.11.89.35', NULL, 'home', 1432724010),
('185.11.89.33', NULL, 'home', 1432724275),
('185.11.89.33', NULL, 'home_media_icons.png', 1432724275),
('185.11.89.33', NULL, 'home', 1432724276),
('185.11.89.33', NULL, 'home', 1432724280),
('185.11.89.33', NULL, 'home', 1432724280),
('185.11.89.33', NULL, 'home', 1432724280),
('185.11.89.33', NULL, 'panel', 1432724293),
('185.11.89.33', NULL, 'home', 1432724294),
('185.11.89.33', NULL, 'panel', 1432724295),
('185.11.89.33', 8, 'success-login', 1432724296),
('185.11.89.33', 8, 'panel', 1432724296),
('185.11.89.33', 8, 'home', 1432724296),
('185.11.89.33', 8, 'home', 1432724298),
('185.11.89.33', 8, 'home', 1432724299),
('185.11.89.33', 8, 'home', 1432724300),
('185.11.89.33', 8, 'home', 1432724303),
('192.99.150.120', NULL, 'home', 1432724851),
('69.171.227.113', NULL, 'home', 1432725124),
('185.11.89.33', 8, 'panel', 1432725191),
('185.11.89.33', 8, 'home', 1432725193),
('185.11.89.33', 8, 'home', 1432725194),
('185.11.89.33', 8, 'home', 1432725195),
('185.11.89.33', 8, 'permission-denied', 1432725199),
('185.11.89.33', 8, 'home', 1432725200),
('185.11.89.33', 8, 'home', 1432725201),
('185.11.89.33', 8, 'panel_logout', 1432725205),
('185.11.89.33', NULL, 'success-logout', 1432725205),
('185.11.89.33', NULL, 'home', 1432725206),
('185.11.89.33', NULL, 'home', 1432725206),
('185.11.89.33', NULL, 'home', 1432725207),
('185.11.89.33', NULL, 'home', 1432725211),
('185.11.89.33', NULL, 'panel_logout', 1432725218),
('185.11.89.33', NULL, 'success-logout', 1432725219),
('185.11.89.33', NULL, 'home', 1432725219),
('185.11.89.33', NULL, 'home', 1432725219),
('185.11.89.33', NULL, 'home', 1432725220),
('185.11.89.33', NULL, 'home', 1432725224),
('185.11.89.33', NULL, 'home_media_icons.png', 1432725224),
('185.11.89.33', NULL, 'home', 1432725225),
('185.11.89.33', NULL, 'home', 1432725225),
('185.11.89.33', NULL, 'home', 1432725226),
('185.11.89.33', NULL, 'home', 1432725226),
('185.11.89.33', NULL, 'home', 1432725786),
('185.11.89.33', NULL, 'home', 1432725820),
('185.11.89.33', NULL, 'home', 1432725881),
('185.11.89.33', NULL, 'home_media_icons.png', 1432725882),
('185.11.89.33', NULL, 'home', 1432725883),
('185.11.89.33', NULL, 'home', 1432725894),
('185.11.89.33', NULL, 'home', 1432725896),
('185.11.89.33', NULL, 'home', 1432725903),
('185.11.89.33', NULL, 'home_media_icons.png', 1432725903),
('185.11.89.33', NULL, 'home', 1432725903),
('185.11.89.33', NULL, 'home', 1432726293),
('185.11.89.33', NULL, 'home_media_icons.png', 1432726294),
('185.11.89.33', NULL, 'home', 1432726294),
('185.11.89.33', NULL, 'home', 1432726896),
('185.11.89.33', NULL, 'home_media_icons.png', 1432726896),
('185.11.89.33', NULL, 'home', 1432727003),
('185.11.89.33', NULL, 'home_media_icons.png', 1432727003),
('185.11.89.33', NULL, 'home', 1432727003),
('185.11.89.33', NULL, 'home', 1432727022),
('185.11.89.33', NULL, 'home_media_icons.png', 1432727022),
('185.11.89.33', NULL, 'home', 1432727023),
('185.11.89.33', NULL, 'home', 1432727026),
('185.11.89.33', NULL, 'home_media_icons.png', 1432727027),
('185.11.89.33', NULL, 'home', 1432727027),
('185.11.89.33', NULL, 'home', 1432727393),
('185.11.89.33', NULL, 'home_media_icons.png', 1432727393),
('185.11.89.33', NULL, 'home', 1432727394),
('185.11.89.33', NULL, 'home', 1432727650),
('185.11.89.33', NULL, 'home_media_icons.png', 1432727650),
('185.11.89.33', NULL, 'home', 1432727650),
('185.11.89.33', NULL, 'home', 1432727653),
('185.11.89.33', NULL, 'home_media_icons.png', 1432727653),
('185.11.89.33', NULL, 'home', 1432727653),
('185.11.89.33', NULL, 'home', 1432727853),
('185.11.89.33', NULL, 'home_media_icons.png', 1432727853),
('185.11.89.33', NULL, 'home', 1432727861),
('185.11.89.33', NULL, 'home_media_icons.png', 1432727861),
('185.11.89.33', NULL, 'home', 1432727862),
('185.11.89.33', NULL, 'home', 1432727879),
('185.11.89.33', NULL, 'home_media_icons.png', 1432727879),
('185.11.89.33', NULL, 'home', 1432727880),
('104.40.137.187', NULL, 'home', 1432730634),
('185.11.89.33', NULL, 'home', 1432730638),
('185.11.89.33', NULL, 'home_media_icons.png', 1432730638),
('185.11.89.33', NULL, 'home', 1432730639),
('185.11.89.33', NULL, 'home', 1432730647),
('185.11.89.33', NULL, 'home', 1432730647),
('185.11.89.33', NULL, 'home', 1432730647),
('185.11.89.33', NULL, 'home', 1432730648),
('185.11.89.33', NULL, 'home', 1432730648),
('185.11.89.33', NULL, 'home', 1432730663),
('185.11.89.33', NULL, 'home_media_icons.png', 1432730664),
('185.11.89.33', NULL, 'home', 1432730664),
('185.11.89.33', NULL, 'panel', 1432732411),
('185.11.89.33', NULL, 'home', 1432732411),
('185.11.89.33', NULL, 'panel', 1432733382),
('185.11.89.33', 8, 'success-login', 1432733382),
('185.11.89.33', 8, 'panel', 1432733383),
('185.11.89.33', 8, 'home', 1432733385),
('185.11.89.33', 8, 'projects_open', 1432733415),
('185.11.89.33', 8, 'send-message_1_S2', 1432733420),
('185.11.89.33', 8, 'ability', 1432733506),
('185.11.89.33', 8, 'edit-profile', 1432733512),
('185.11.89.33', 8, 'event_9', 1432733522),
('185.11.89.33', 8, 'home', 1432733522),
('123.125.71.82', NULL, 'home', 1432738035),
('128.69.223.69', NULL, 'home', 1432741127),
('5.239.104.240', NULL, 'home', 1432744174),
('5.239.104.240', NULL, 'home_media_icons.png', 1432744174),
('5.239.104.240', NULL, 'home', 1432744179),
('5.239.104.240', NULL, 'home', 1432744179),
('5.239.104.240', NULL, 'panel', 1432748448),
('2.186.101.98', NULL, 'home', 1432759362),
('209.126.107.104', NULL, 'home', 1432764198),
('2.186.101.98', NULL, 'home', 1432769234),
('104.40.136.254', NULL, 'home', 1432796189),
('157.55.39.155', NULL, 'home_offer.aspx', 1432799040),
('107.150.63.131', NULL, 'bad-browser', 1432816476),
('185.11.89.33', NULL, 'home', 1432829402),
('185.11.89.33', NULL, 'home_media_icons.png', 1432829406),
('185.11.89.33', NULL, 'home', 1432829730),
('185.11.89.33', NULL, 'home', 1432829734),
('151.246.143.217', NULL, 'home', 1432831985),
('151.246.143.217', NULL, 'home_media_icons.png', 1432831989),
('151.246.143.217', NULL, 'home', 1432832044),
('157.55.39.194', NULL, 'home', 1432836887),
('5.239.94.30', NULL, 'home', 1432843818),
('5.239.94.30', NULL, 'home_media_icons.png', 1432843820),
('5.239.94.30', NULL, 'panel', 1432843823),
('5.239.94.30', NULL, 'panel', 1432843829),
('5.239.94.30', 50, 'success-login', 1432843829),
('5.239.94.30', 50, 'panel', 1432843830),
('5.239.94.30', 50, 'home', 1432843831),
('5.239.94.30', 50, 'home', 1432843832),
('5.239.94.30', 50, 'manage-projects', 1432843906);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ability`
--
ALTER TABLE `ability`
  ADD CONSTRAINT `ability_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users_sub` (`id`);

--
-- Constraints for table `bids`
--
ALTER TABLE `bids`
  ADD CONSTRAINT `bids_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`),
  ADD CONSTRAINT `bids_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users_sub` (`id`);

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users_sub` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `groups`
--
ALTER TABLE `groups`
  ADD CONSTRAINT `groups_ibfk_1` FOREIGN KEY (`creator`) REFERENCES `users_sub` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `group_files`
--
ALTER TABLE `group_files`
  ADD CONSTRAINT `group_files_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users_sub` (`id`),
  ADD CONSTRAINT `group_files_ibfk_2` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`);

--
-- Constraints for table `group_members`
--
ALTER TABLE `group_members`
  ADD CONSTRAINT `group_members_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`),
  ADD CONSTRAINT `group_members_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users_sub` (`id`);

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `projects_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`);

--
-- Constraints for table `twitts`
--
ALTER TABLE `twitts`
  ADD CONSTRAINT `twitts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users_sub` (`id`);

--
-- Constraints for table `user_visit`
--
ALTER TABLE `user_visit`
  ADD CONSTRAINT `user_visit_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users_sub` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
